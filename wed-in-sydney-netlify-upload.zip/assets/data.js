function wisAreaForVendor(vendor) {
  const text = `${vendor.location} ${(vendor.areasServiced || []).join(" ")}`.toLowerCase();
  if (/point piper|eastern|surry hills|chippendale/.test(text)) return "Eastern Suburbs";
  if (/mosman|north shore|northern beaches|milsons point|hornsby|artarmon|chowder bay/.test(text)) return "Northern Beaches / North Shore";
  if (/pyrmont|leichhardt|camperdown|stanmore|inner west/.test(text)) return "Inner West";
  if (/oatlands|parramatta|seven hills|western/.test(text)) return "Western Sydney";
  if (/hills/.test(text)) return "Hills District";
  if (/sylvania|sutherland/.test(text)) return "Sutherland Shire";
  if (/penrith|blue mountains/.test(text)) return "Blue Mountains / Penrith";
  if (/cbd|city|sydney/.test(text)) return "Sydney CBD";
  return "Sydney-wide";
}

function wisBudgetFeelForVendor(vendor) {
  const text = `${vendor.category} ${vendor.tags.join(" ")} ${vendor.description}`.toLowerCase();
  if (/luxury|premium|ballroom|editorial|grand/.test(text)) return "Luxury";
  if (/waterfront|harbour|estate|elegant|cinematic/.test(text)) return "Premium";
  if (/simple|intimate|relaxed|natural/.test(text)) return "Affordable";
  return "Mid-range";
}

const WIS_VENDOR_IMAGE_KEYS = {
  "Zest Waterfront Venues": "vendorZestWaterfront",
  "Sergeants' Mess": "vendorSergeantsMess",
  "Gunners Barracks": "vendorGunnersBarracks",
  "Doltone House": "vendorDoltoneHouse",
  "Oatlands Estate": "vendorOatlandsEstate",
  "Salt Atelier": "vendorSaltAtelier",
  "Dreamlife Wedding Photography": "vendorDreamlife",
  "Sydney Wedding Photography by Katsu": "vendorKatsu",
  "Two Peaches Photography": "vendorTwoPeaches",
  "Splendid Photos & Video": "vendorSplendid",
  "Celebrant Melissa Soncini": "vendorMelissaSoncini",
  "Simple Ceremonies": "vendorSimpleCeremonies",
  "Carla Davern Celebrant": "vendorCarlaDavern",
  "Married by Allegra": "vendorMarriedByAllegra",
  "Married by Adam": "vendorMarriedByAdam",
  "Best Buds Florist": "vendorBestBuds",
  "Chiho Kobayashi Flowers": "vendorChihoFlowers",
  "Pearsons Florist": "vendorPearsons",
  "Melissa D'Cruz Floral": "vendorMelissaFloral",
  "The Sisters": "vendorTheSisters",
  "The White Tree": "vendorWhiteTree",
  "XYDJ": "vendorXydj",
  "DJ:Plus! Entertainment": "vendorDjPlus",
  "Baker Boys Band": "vendorBakerBoys",
  "Evoke Entertainment": "vendorEvoke",
  "Radish Events": "vendorRadish",
  "Flavours Catering + Events": "vendorFlavours",
  "Bespoke Catering Sydney": "vendorBespokeCatering",
  "Laissez-faire Catering": "vendorLaissezFaire",
  "Gastronomy": "vendorGastronomy",
  "Faye Cahill Cake Design": "vendorFayeCahill",
  "Sweet Art": "vendorSweetArt",
  "Savvy Cakes": "vendorSavvyCakes",
  "Black Velvet Sydney": "vendorBlackVelvet",
  "Petal Met Sugar": "vendorPetalMetSugar",
  "Makeup by Megan": "vendorMakeupMegan",
  "Makeup Mode": "vendorMakeupMode",
  "Domenic Pelli": "vendorDomenicPelli",
  "Amy Chan Hair & Makeup Artistry": "vendorAmyChan",
  "Liv Lundelius Makeup Artist": "vendorLivLundelius"
};

window.WIS_DATA = {
  imageLibrary: {
    harbour: {
      url: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1600&q=84",
      alt: "Wedding couple standing beneath an elegant floral ceremony arch"
    },
    venue: {
      url: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=1400&q=82",
      alt: "Elegant wedding reception room with tables and floral styling"
    },
    reception: {
      url: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding reception tables with candlelight and flowers"
    },
    portrait: {
      url: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1400&q=82",
      alt: "Newly married couple holding hands after their ceremony"
    },
    florals: {
      url: "https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=1400&q=82",
      alt: "Soft blush and white wedding flowers arranged for a celebration"
    },
    ceremony: {
      url: "https://images.unsplash.com/photo-1523438885200-e635ba2c371e?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding ceremony with guests gathered around the couple"
    },
    catering: {
      url: "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=1400&q=82",
      alt: "Refined wedding catering plates being prepared"
    },
    cake: {
      url: "https://images.unsplash.com/photo-1535254973040-607b474cb50d?auto=format&fit=crop&w=1400&q=82",
      alt: "Modern tiered wedding cake with delicate decoration"
    },
    beauty: {
      url: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&w=1400&q=82",
      alt: "Bridal hair and makeup brushes arranged on a dressing table"
    },
    music: {
      url: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding reception dance floor with warm lights"
    },
    vendorZestWaterfront: {
      url: "https://images.unsplash.com/photo-1502635385003-ee1e6a1a742d?auto=format&fit=crop&w=1400&q=82",
      alt: "Waterfront wedding reception set beside sparkling harbour water"
    },
    vendorSergeantsMess: {
      url: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&w=1400&q=82",
      alt: "Elegant harbourside wedding ceremony with white chairs and floral styling"
    },
    vendorGunnersBarracks: {
      url: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=1400&q=82",
      alt: "Heritage wedding estate with garden ceremony seating"
    },
    vendorDoltoneHouse: {
      url: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1400&q=82",
      alt: "Grand city wedding reception with candlelit tables"
    },
    vendorOatlandsEstate: {
      url: "https://images.unsplash.com/photo-1523438885200-e635ba2c371e?auto=format&fit=crop&w=1400&q=82",
      alt: "Romantic garden wedding ceremony on a lawn"
    },
    vendorSaltAtelier: {
      url: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1400&q=82",
      alt: "Editorial wedding portrait of a couple holding hands"
    },
    vendorDreamlife: {
      url: "https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding photographer capturing a couple during golden hour portraits"
    },
    vendorKatsu: {
      url: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1400&q=82",
      alt: "Natural wedding portrait with couple walking after the ceremony"
    },
    vendorTwoPeaches: {
      url: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=1400&q=82",
      alt: "Warm candid wedding moment with guests celebrating"
    },
    vendorSplendid: {
      url: "https://images.unsplash.com/photo-1509610973147-232dfea52a97?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding couple portrait captured in soft evening light"
    },
    vendorMelissaSoncini: {
      url: "https://images.unsplash.com/photo-1469371670807-013ccf25f16a?auto=format&fit=crop&w=1400&q=82",
      alt: "Celebrant-led wedding ceremony with guests gathered outdoors"
    },
    vendorSimpleCeremonies: {
      url: "https://images.unsplash.com/photo-1505944357431-27579db47558?auto=format&fit=crop&w=1400&q=82",
      alt: "Simple intimate wedding ceremony setup with white seating"
    },
    vendorCarlaDavern: {
      url: "https://images.unsplash.com/photo-1513278974582-3e1b4a4fa21e?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding vows being read during a warm ceremony"
    },
    vendorMarriedByAllegra: {
      url: "https://images.unsplash.com/photo-1519741347686-c1e0aadf4611?auto=format&fit=crop&w=1400&q=82",
      alt: "Modern outdoor wedding ceremony with floral aisle styling"
    },
    vendorMarriedByAdam: {
      url: "https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?auto=format&fit=crop&w=1400&q=82",
      alt: "Couple laughing together during their wedding ceremony"
    },
    vendorBestBuds: {
      url: "https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=1400&q=82",
      alt: "Soft blush wedding flowers arranged in a bridal bouquet"
    },
    vendorChihoFlowers: {
      url: "https://images.unsplash.com/photo-1509719662281-777d0ccf2734?auto=format&fit=crop&w=1400&q=82",
      alt: "Artful white and green wedding floral arrangement"
    },
    vendorPearsons: {
      url: "https://images.unsplash.com/photo-1518709766631-a6a7f45921c3?auto=format&fit=crop&w=1400&q=82",
      alt: "Classic wedding bouquet with white flowers and greenery"
    },
    vendorMelissaFloral: {
      url: "https://images.unsplash.com/photo-1525310072745-f49212b5ac6d?auto=format&fit=crop&w=1400&q=82",
      alt: "Lush colourful wedding floral installation"
    },
    vendorTheSisters: {
      url: "https://images.unsplash.com/photo-1507504031003-b417219a0fde?auto=format&fit=crop&w=1400&q=82",
      alt: "Styled wedding tablescape with candles and floral arrangements"
    },
    vendorWhiteTree: {
      url: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding dance floor with live music atmosphere"
    },
    vendorXydj: {
      url: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=1400&q=82",
      alt: "DJ lights and dancing guests at a wedding reception"
    },
    vendorDjPlus: {
      url: "https://images.unsplash.com/photo-1505236858219-8359eb29e329?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding reception party with music and warm lighting"
    },
    vendorBakerBoys: {
      url: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=1400&q=82",
      alt: "Live band performing under warm event lighting"
    },
    vendorEvoke: {
      url: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1400&q=82",
      alt: "Live performers creating energy at an evening reception"
    },
    vendorRadish: {
      url: "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=1400&q=82",
      alt: "Seasonal wedding catering plates being prepared"
    },
    vendorFlavours: {
      url: "https://images.unsplash.com/photo-1528605248644-14dd04022da1?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding guests enjoying shared catering at long tables"
    },
    vendorBespokeCatering: {
      url: "https://images.unsplash.com/photo-1544148103-0773bf10d330?auto=format&fit=crop&w=1400&q=82",
      alt: "Refined plated wedding meal with elegant presentation"
    },
    vendorLaissezFaire: {
      url: "https://images.unsplash.com/photo-1551218808-94e220e084d2?auto=format&fit=crop&w=1400&q=82",
      alt: "Chef preparing elegant event catering"
    },
    vendorGastronomy: {
      url: "https://images.unsplash.com/photo-1470337458703-46ad1756a187?auto=format&fit=crop&w=1400&q=82",
      alt: "Premium canapes and drinks prepared for an event"
    },
    vendorFayeCahill: {
      url: "https://images.unsplash.com/photo-1535254973040-607b474cb50d?auto=format&fit=crop&w=1400&q=82",
      alt: "Elegant tiered wedding cake with delicate floral detail"
    },
    vendorSweetArt: {
      url: "https://images.unsplash.com/photo-1621303837174-89787a7d4729?auto=format&fit=crop&w=1400&q=82",
      alt: "Classic wedding cake with smooth white icing"
    },
    vendorSavvyCakes: {
      url: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1400&q=82",
      alt: "Modern celebration cake with soft decorative detail"
    },
    vendorBlackVelvet: {
      url: "https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?auto=format&fit=crop&w=1400&q=82",
      alt: "Contemporary dessert table with cakes and sweet details"
    },
    vendorPetalMetSugar: {
      url: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?auto=format&fit=crop&w=1400&q=82",
      alt: "Artful wedding cake with floral decoration"
    },
    vendorMakeupMegan: {
      url: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&w=1400&q=82",
      alt: "Bridal makeup brushes and products on a getting-ready table"
    },
    vendorMakeupMode: {
      url: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?auto=format&fit=crop&w=1400&q=82",
      alt: "Bridal makeup artist preparing a soft glam look"
    },
    vendorDomenicPelli: {
      url: "https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding hair styling tools and bridal accessories"
    },
    vendorAmyChan: {
      url: "https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?auto=format&fit=crop&w=1400&q=82",
      alt: "Bridal beauty preparation with soft natural makeup"
    },
    vendorLivLundelius: {
      url: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=1400&q=82",
      alt: "Natural bridal beauty portrait with soft light"
    },
    planningBudget: {
      url: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding budget planning flat lay with notebook, pen and stationery"
    },
    planningVenueChoice: {
      url: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&w=1400&q=82",
      alt: "Elegant wedding ceremony space prepared for venue planning"
    },
    planningPhotographyCost: {
      url: "https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding photographer capturing a couple during portraits"
    },
    planningSupplierCompare: {
      url: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1400&q=82",
      alt: "Couple comparing wedding supplier notes on a laptop"
    },
    planningChecklist: {
      url: "https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=1400&q=82",
      alt: "Wedding planning checklist notebook with pen and stationery"
    },
    planningVenueQuestions: {
      url: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1400&q=82",
      alt: "Refined wedding reception table setting for venue questions"
    }
  },
  categories: [
    { label: "Venues", category: "Venues", icon: "V", note: "Harbour views, garden estates and elegant reception rooms", href: "/venues/" },
    { label: "Photographers", category: "Photographers", icon: "P", note: "Editorial, candid and documentary wedding stories", href: "/photographers/" },
    { label: "Celebrants", category: "Celebrants", icon: "C", note: "Warm ceremonies, legal details and beautiful words", href: "/celebrants/" },
    { label: "Florals & Styling", category: "Florists / Stylists", icon: "S", note: "Bouquets, ceremony flowers and reception styling", href: "/categories/" },
    { label: "Music & DJs", category: "Entertainment / DJs", icon: "M", note: "Live music, DJs and dance floor energy", href: "/categories/" },
    { label: "Catering", category: "Caterers", icon: "F", note: "Menus, grazing tables and full-service dining", href: "/categories/" },
    { label: "Cakes", category: "Wedding Cakes", icon: "K", note: "Modern cakes, sugar florals and dessert moments", href: "/categories/" },
    { label: "Hair & Makeup", category: "Bridal Hair and Makeup", icon: "H", note: "Calm getting-ready mornings and polished beauty", href: "/categories/" }
  ],
  areaFilters: ["Sydney CBD", "Eastern Suburbs", "Northern Beaches / North Shore", "Inner West", "Western Sydney", "Hills District", "Sutherland Shire", "Blue Mountains / Penrith", "Sydney-wide"],
  budgetFeels: ["Affordable", "Mid-range", "Premium", "Luxury"],
  questionPrompts: {
    Venues: ["What dates are available?", "What is included in the package?", "Are there minimum spends?", "What happens if it rains?", "Can we use external suppliers?", "How many hours are included?"],
    Photographers: ["How many hours are included?", "Do you provide full galleries to review?", "When will we receive previews?", "Is a second shooter available?", "Are travel fees included?", "Can we add albums or film?"],
    Celebrants: ["How do you shape the ceremony?", "Can you help with vows?", "What legal paperwork is included?", "How early do you arrive?", "Do you offer rehearsal support?", "Can you work with our music or MC plans?"],
    default: ["What dates are available?", "What is included?", "What costs extra?", "How far do you travel?", "How do bookings and payments work?", "What should we prepare before enquiring?"]
  },
  styleFinder: {
    settings: ["Harbour", "Garden", "Ballroom", "Coastal", "City"],
    guestCounts: ["Under 60", "60-120", "120+"],
    budgetFeels: ["Affordable", "Mid-range", "Premium"],
    recommendations: {
      Harbour: ["Start with waterfront venues, photographers and florals that do not fight the view.", "/inspiration/harbour-weddings/", "/venues/sydney/"],
      Garden: ["Look at estate venues, romantic florals and a celebrant who can hold a relaxed ceremony.", "/inspiration/garden-estate-weddings/", "/guides/best-garden-wedding-venues-sydney/"],
      Ballroom: ["Prioritise reception flow, music, cake and photography that can capture candlelight well.", "/inspiration/luxury-ballroom-weddings/", "/guides/sydney-wedding-venue-cost-guide/"],
      Coastal: ["Keep the styling natural and ask photographers about wind, light and timing near the water.", "/inspiration/coastal-weddings/", "/photographers/sydney/"],
      City: ["For a city wedding, compare access, private dining, celebrants and compact photo locations.", "/inspiration/intimate-city-weddings/", "/planning/how-to-compare-wedding-suppliers/"]
    }
  },
  vendors: [
    {
      name: "Zest Waterfront Venues",
      category: "Venues",
      location: "Point Piper and The Spit",
      websiteUrl: "https://www.zest.net.au/",
      imageKey: "harbour",
      description: "Waterfront wedding spaces for couples dreaming of a polished Sydney celebration close to the harbour.",
      tags: ["waterfront", "harbour", "modern", "reception"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding receptions", "Ceremony spaces", "Waterfront events", "Menu packages"],
      areasServiced: ["Point Piper", "The Spit", "Sydney Harbour"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Sergeants' Mess",
      category: "Venues",
      location: "Chowder Bay",
      websiteUrl: "https://sergeantsmess.com.au/",
      imageKey: "harbour",
      description: "A harbour-facing venue with historic character, sweeping views and a romantic Mosman setting.",
      tags: ["harbour", "historic", "waterfront", "elegant"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding receptions", "Ceremonies", "Private celebrations", "Harbourside dining"],
      areasServiced: ["Mosman", "Chowder Bay", "Sydney Harbour"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Gunners Barracks",
      category: "Venues",
      location: "Mosman",
      websiteUrl: "https://gunnersbarracks.com.au/",
      imageKey: "venue",
      description: "A heritage venue for couples drawn to sandstone, harbour views and a classic Sydney atmosphere.",
      tags: ["heritage", "harbour", "classic", "intimate"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Ceremonies", "Wedding receptions", "High tea celebrations", "Private dining"],
      areasServiced: ["Mosman", "Lower North Shore", "Sydney Harbour"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Doltone House",
      category: "Venues",
      location: "Sydney CBD, Pyrmont and Sylvania Waters",
      websiteUrl: "https://www.doltonehouse.com.au/",
      imageKey: "reception",
      description: "Large-scale Sydney wedding spaces for couples wanting city polish, water views or a grand reception feel.",
      tags: ["city", "waterfront", "large weddings", "elegant"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Reception packages", "Ceremonies", "Event coordination", "Food and beverage"],
      areasServiced: ["Sydney CBD", "Pyrmont", "Darling Island", "Sylvania Waters"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Oatlands Estate",
      category: "Venues",
      location: "Oatlands",
      websiteUrl: "https://www.oatlandsestate.com.au/",
      imageKey: "venue",
      description: "A garden estate setting for couples who want heritage charm, open grounds and a softer Western Sydney feel.",
      tags: ["garden", "estate", "heritage", "romantic"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding receptions", "Ceremonies", "Garden events", "Estate photography locations"],
      areasServiced: ["Oatlands", "Parramatta", "Western Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Salt Atelier",
      category: "Photographers",
      location: "Camperdown",
      websiteUrl: "https://saltatelier.com/",
      imageKey: "portrait",
      description: "A Sydney photo and film studio for couples who love a refined, cinematic wedding story.",
      tags: ["editorial", "photo and film", "modern", "romantic"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding photography", "Wedding films", "Albums", "Pre-wedding sessions"],
      areasServiced: ["Sydney", "NSW", "Destination weddings"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Dreamlife Wedding Photography",
      category: "Photographers",
      location: "Stanmore",
      websiteUrl: "https://www.dreamlifewedding.com.au/",
      imageKey: "portrait",
      description: "Photography and film coverage for couples wanting a complete wedding story from morning to dance floor.",
      tags: ["photo and video", "classic", "full day", "albums"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Photography", "Videography", "Albums", "Pre-wedding shoots"],
      areasServiced: ["Sydney", "Greater Sydney", "NSW"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Sydney Wedding Photography by Katsu",
      category: "Photographers",
      location: "Surry Hills",
      websiteUrl: "https://www.sydneyweddingphotographybykatsu.com.au/",
      imageKey: "portrait",
      description: "Personal wedding photography for couples who want calm direction and a natural record of the day.",
      tags: ["personal", "boutique", "natural", "city weddings"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding photography", "Elopements", "Portraits", "Pre-wedding sessions"],
      areasServiced: ["Sydney", "Eastern Suburbs", "Inner City"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Two Peaches Photography",
      category: "Photographers",
      location: "Artarmon",
      websiteUrl: "https://www.twopeaches.com.au/",
      imageKey: "portrait",
      description: "Sydney wedding photography for couples planning big family moments, lively receptions and generous timelines.",
      tags: ["candid", "large groups", "family", "warm"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding photography", "Engagement sessions", "Albums", "Family portraits"],
      areasServiced: ["Sydney", "North Shore", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Splendid Photos & Video",
      category: "Photographers",
      location: "Leichhardt",
      websiteUrl: "https://splendid.net.au/",
      imageKey: "portrait",
      description: "Photo and video coverage for couples who want a polished record of the ceremony, portraits and reception.",
      tags: ["photo and video", "inner west", "classic", "reception"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Photography", "Videography", "Albums", "Same-day style edits"],
      areasServiced: ["Sydney", "Inner West", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Celebrant Melissa Soncini",
      category: "Celebrants",
      location: "Surry Hills",
      websiteUrl: "https://www.melissasoncini.com.au/",
      imageKey: "ceremony",
      description: "Warm ceremony support for couples who want words that feel personal, relaxed and sincere.",
      tags: ["warm", "personal", "ceremony", "MC option"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Marriage ceremonies", "Vow support", "MC services", "Ceremony planning"],
      areasServiced: ["Sydney", "Inner City", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Simple Ceremonies",
      category: "Celebrants",
      location: "Milsons Point",
      websiteUrl: "https://www.simpleceremonies.com.au/",
      imageKey: "ceremony",
      description: "A streamlined celebrant option for couples who want the legal details handled clearly and calmly.",
      tags: ["simple", "legal", "city", "ceremony"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Legal marriage ceremonies", "Registry-style ceremonies", "Paperwork", "Ceremony guidance"],
      areasServiced: ["Sydney", "North Sydney", "Milsons Point"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Carla Davern Celebrant",
      category: "Celebrants",
      location: "Hornsby Heights",
      websiteUrl: "https://www.carladavern.com.au/",
      imageKey: "ceremony",
      description: "A versatile Sydney celebrant for couples wanting ceremony, music and MC energy in one warm presence.",
      tags: ["versatile", "MC", "music", "personal"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Marriage ceremonies", "MC services", "Music support", "Vow writing"],
      areasServiced: ["Sydney", "Hornsby", "North Shore"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Married by Allegra",
      category: "Celebrants",
      location: "Sydney-wide",
      websiteUrl: "https://marriedbyallegra.com.au/",
      imageKey: "ceremony",
      description: "A modern celebrant choice for couples wanting a ceremony that feels easy, human and beautifully paced.",
      tags: ["modern", "relaxed", "personal", "romantic"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding ceremonies", "Elopements", "Vow support", "Ceremony planning"],
      areasServiced: ["Sydney", "Greater Sydney", "NSW"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Married by Adam",
      category: "Celebrants",
      location: "Sydney-wide",
      websiteUrl: "https://www.marriedbyadam.com.au/",
      imageKey: "ceremony",
      description: "Ceremony support for couples who want something heartfelt, unfussy and full of their own rhythm.",
      tags: ["relaxed", "modern", "story-led", "ceremony"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Marriage ceremonies", "Elopements", "Ceremony writing", "Legal paperwork"],
      areasServiced: ["Sydney", "Greater Sydney", "NSW"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Best Buds Florist",
      category: "Florists / Stylists",
      location: "Chippendale",
      websiteUrl: "https://www.bestbuds.com.au/",
      imageKey: "florals",
      description: "Florals for couples wanting romantic texture, soft colour and thoughtful ceremony-to-reception styling.",
      tags: ["romantic", "florals", "silk flowers", "city"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Bouquets", "Ceremony flowers", "Reception flowers", "Silk flower options"],
      areasServiced: ["Chippendale", "Sydney CBD", "Inner Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Chiho Kobayashi Flowers",
      category: "Florists / Stylists",
      location: "Ermington",
      websiteUrl: "https://www.chihokobayashi.com.au/",
      imageKey: "florals",
      description: "Boutique floral work for couples drawn to delicate, artful arrangements and a softer wedding mood.",
      tags: ["boutique", "artful", "soft", "appointment"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding bouquets", "Ceremony styling", "Reception arrangements", "Consultations"],
      areasServiced: ["Sydney", "Ermington", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Pearsons Florist",
      category: "Florists / Stylists",
      location: "Sydney-wide",
      websiteUrl: "https://pearsonsflorist.com.au/",
      imageKey: "florals",
      description: "Established Sydney florals for couples wanting reliable bouquets, styling and reception arrangements.",
      tags: ["classic", "reliable", "bouquets", "reception"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Bouquets", "Buttonholes", "Ceremony flowers", "Reception styling"],
      areasServiced: ["Sydney", "Inner West", "North Shore"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Melissa D'Cruz Floral",
      category: "Florists / Stylists",
      location: "Seven Hills",
      websiteUrl: "https://www.melissadcruzfloral.com.au/",
      imageKey: "florals",
      description: "Lush arrangements for couples who love abundant flowers, romantic colour and a generous floral moment.",
      tags: ["lush", "romantic", "western Sydney", "arrangements"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Bouquets", "Installations", "Ceremony florals", "Reception styling"],
      areasServiced: ["Seven Hills", "Western Sydney", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "The Sisters",
      category: "Florists / Stylists",
      location: "Sydney-wide",
      websiteUrl: "https://thesisters.com.au/",
      imageKey: "florals",
      description: "Wedding styling and florals for couples wanting a cohesive visual story from aisle to tablescape.",
      tags: ["styling", "editorial", "tablescape", "modern"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding styling", "Florals", "Tablescapes", "Creative direction"],
      areasServiced: ["Sydney", "Greater Sydney", "NSW"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "The White Tree",
      category: "Entertainment / DJs",
      location: "Sydney-wide",
      websiteUrl: "https://www.thewhitetree.com.au/",
      imageKey: "music",
      description: "Live music and DJ energy for couples who want the ceremony, cocktails and dance floor to feel connected.",
      tags: ["live music", "DJ", "modern", "dance floor"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Live bands", "DJs", "Acoustic sets", "Wedding entertainment"],
      areasServiced: ["Sydney", "NSW", "Destination weddings"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "XYDJ",
      category: "Entertainment / DJs",
      location: "Sydney-wide",
      websiteUrl: "https://www.xydj.com.au/",
      imageKey: "music",
      description: "Wedding DJ services for couples who care about atmosphere, timing and a packed reception floor.",
      tags: ["DJ", "reception", "party", "modern"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding DJ", "MC options", "Reception music", "Dance floor lighting"],
      areasServiced: ["Sydney", "Greater Sydney", "NSW"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "DJ:Plus! Entertainment",
      category: "Entertainment / DJs",
      location: "Sydney-wide",
      websiteUrl: "https://www.djplus.com.au/",
      imageKey: "music",
      description: "Entertainment support for couples wanting music, MC flow and a reception that feels effortless.",
      tags: ["DJ", "MC", "reception", "personal"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding DJ", "MC services", "Ceremony sound", "Reception entertainment"],
      areasServiced: ["Sydney", "Greater Sydney", "Blue Mountains"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Baker Boys Band",
      category: "Entertainment / DJs",
      location: "Sydney-wide",
      websiteUrl: "https://www.bakerboysband.com.au/",
      imageKey: "music",
      description: "Live wedding music for couples wanting a warm ceremony sound and a reception with real movement.",
      tags: ["live band", "acoustic", "dance floor", "ceremony"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Live bands", "Acoustic duos", "DJ add-ons", "Ceremony music"],
      areasServiced: ["Sydney", "NSW", "Australia"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Evoke Entertainment",
      category: "Entertainment / DJs",
      location: "Sydney-wide",
      websiteUrl: "https://www.evokeentertainment.com.au/",
      imageKey: "music",
      description: "Entertainment options for couples wanting live performers, atmosphere and a memorable reception arc.",
      tags: ["live music", "performers", "reception", "party"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Live music", "DJs", "Performers", "Event entertainment"],
      areasServiced: ["Sydney", "Greater Sydney", "NSW"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Radish Events",
      category: "Caterers",
      location: "St Peters",
      websiteUrl: "https://www.radishevents.com.au/",
      imageKey: "catering",
      description: "Seasonal catering for couples who want thoughtful menus, generous grazing and a relaxed shared-table feel.",
      tags: ["seasonal", "grazing", "sustainable", "fresh"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding catering", "Grazing tables", "Canapes", "Event menus"],
      areasServiced: ["Sydney", "Inner West", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Flavours Catering + Events",
      category: "Caterers",
      location: "Artarmon",
      websiteUrl: "https://www.flavourscatering.com.au/",
      imageKey: "catering",
      description: "Full-service catering for couples wanting menu choice, staff support and a smooth reception meal.",
      tags: ["full service", "menus", "canapes", "reception"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding catering", "Canapes", "Buffets", "Staffing"],
      areasServiced: ["Sydney", "North Shore", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Bespoke Catering Sydney",
      category: "Caterers",
      location: "Neutral Bay",
      websiteUrl: "https://www.bespokecateringsydney.com.au/",
      imageKey: "catering",
      description: "Premium catering for intimate weddings, private estates and couples who want the meal to feel personal.",
      tags: ["premium", "intimate", "private events", "menus"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Private catering", "Wedding menus", "Canapes", "Shared dining"],
      areasServiced: ["Sydney", "Lower North Shore", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Laissez-faire Catering",
      category: "Caterers",
      location: "Sydney",
      websiteUrl: "https://www.laissez.com.au/",
      imageKey: "catering",
      description: "Sydney catering for couples planning stylish receptions, cocktail celebrations or venue-based dining.",
      tags: ["cocktail", "menus", "events", "reception"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding catering", "Cocktail menus", "Event staffing", "Beverage service"],
      areasServiced: ["Sydney", "Greater Sydney", "NSW"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Gastronomy",
      category: "Caterers",
      location: "Sydney",
      websiteUrl: "https://www.gastronomy.com.au/",
      imageKey: "catering",
      description: "Catering and event food for couples wanting a considered dining experience with plenty of detail.",
      tags: ["event dining", "canapes", "premium", "menus"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding catering", "Corporate-style service", "Canapes", "Plated dining"],
      areasServiced: ["Sydney", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Faye Cahill Cake Design",
      category: "Wedding Cakes",
      location: "Sydney",
      websiteUrl: "https://www.fayecahill.com.au/",
      imageKey: "cake",
      description: "Elegant wedding cakes for couples who love delicate detail, sugar florals and a refined reception moment.",
      tags: ["luxury", "sugar flowers", "elegant", "custom"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding cakes", "Sugar flowers", "Custom design", "Consultations"],
      areasServiced: ["Sydney", "Greater Sydney", "NSW"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Sweet Art",
      category: "Wedding Cakes",
      location: "Paddington",
      websiteUrl: "https://sweetart.com.au/",
      imageKey: "cake",
      description: "Sydney wedding cakes for couples wanting classic tiers, celebration desserts and a beautifully finished table.",
      tags: ["classic", "tiers", "dessert", "Sydney"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding cakes", "Celebration cakes", "Desserts", "Custom orders"],
      areasServiced: ["Paddington", "Sydney", "Eastern Suburbs"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Savvy Cakes",
      category: "Wedding Cakes",
      location: "Sydney",
      websiteUrl: "https://savvycakes.com.au/",
      imageKey: "cake",
      description: "Custom wedding cakes for couples who want a cake that suits the venue, flowers and overall mood.",
      tags: ["custom", "modern", "romantic", "dessert"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding cakes", "Custom design", "Dessert tables", "Consultations"],
      areasServiced: ["Sydney", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Black Velvet Sydney",
      category: "Wedding Cakes",
      location: "Darlinghurst",
      websiteUrl: "https://bvsydney.com.au/",
      imageKey: "cake",
      description: "Modern cakes and cupcakes for couples who want a sweet finish that still feels designed.",
      tags: ["modern", "cupcakes", "dessert", "city"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding cakes", "Cupcakes", "Dessert styling", "Custom orders"],
      areasServiced: ["Darlinghurst", "Sydney CBD", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Petal Met Sugar",
      category: "Wedding Cakes",
      location: "Sydney",
      websiteUrl: "https://www.petalmet.com.au/",
      imageKey: "cake",
      description: "Artful cakes for couples drawn to painterly finishes, soft florals and a cake that feels personal.",
      tags: ["artful", "floral", "custom", "romantic"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Wedding cakes", "Sugar flowers", "Custom cake design", "Consultations"],
      areasServiced: ["Sydney", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Makeup by Megan",
      category: "Bridal Hair and Makeup",
      location: "Sydney-wide",
      websiteUrl: "https://makeupbymegan.com.au/",
      imageKey: "beauty",
      description: "Bridal makeup for couples wanting a calm morning, polished skin and a look that still feels like them.",
      tags: ["makeup", "natural glam", "bridal", "calm"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Bridal makeup", "Bridesmaids", "Trials", "Touch-ups"],
      areasServiced: ["Sydney", "Greater Sydney", "NSW"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Makeup Mode",
      category: "Bridal Hair and Makeup",
      location: "Sydney",
      websiteUrl: "https://makeupmode.com.au/",
      imageKey: "beauty",
      description: "Hair and makeup styling for wedding mornings that need to feel organised, polished and relaxed.",
      tags: ["hair", "makeup", "bridal party", "polished"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Bridal hair", "Bridal makeup", "Trials", "Bridal party styling"],
      areasServiced: ["Sydney", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Domenic Pelli",
      category: "Bridal Hair and Makeup",
      location: "Sydney",
      websiteUrl: "https://www.domenicpelli.com/",
      imageKey: "beauty",
      description: "Bridal hair styling for couples wanting a fashion-aware look with a calm, experienced hand.",
      tags: ["hair", "bridal styling", "editorial", "modern"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Bridal hair", "Hair styling", "Trials", "Wedding morning styling"],
      areasServiced: ["Sydney", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Amy Chan Hair & Makeup Artistry",
      category: "Bridal Hair and Makeup",
      location: "Sydney",
      websiteUrl: "https://www.amychan.net.au/",
      imageKey: "beauty",
      description: "Wedding hair and makeup for couples wanting soft glam, practical timing and a polished bridal party.",
      tags: ["hair", "makeup", "soft glam", "bridal party"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Bridal hair", "Bridal makeup", "Trials", "Bridesmaids"],
      areasServiced: ["Sydney", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    },
    {
      name: "Liv Lundelius Makeup Artist",
      category: "Bridal Hair and Makeup",
      location: "Sydney",
      websiteUrl: "https://www.livlundelius.com/",
      imageKey: "beauty",
      description: "Makeup artistry for couples who want skin-focused beauty, thoughtful preparation and a relaxed morning.",
      tags: ["makeup", "skin focused", "natural", "bridal"],
      priceGuide: "Request quote",
      reviewNote: "Reviews: see vendor website",
      services: ["Bridal makeup", "Trials", "Editorial makeup", "Wedding day makeup"],
      areasServiced: ["Sydney", "Greater Sydney"],
      sourceNote: "Inspired by public information from the vendor website.",
      inspiredByRealVendor: true
    }
  ].map((vendor, index) => ({
    ...vendor,
    imageKey: WIS_VENDOR_IMAGE_KEYS[vendor.name] || vendor.imageKey,
    id: index + 1,
    area: wisAreaForVendor(vendor),
    budgetFeel: wisBudgetFeelForVendor(vendor),
    slug: vendor.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "")
  })),
  realWeddings: [
    {
      slug: "harbour-wedding-sydney",
      title: "A modern harbour wedding with sunset portraits",
      coupleNames: "Mia & Daniel",
      venue: "Harbour venue inspiration",
      location: "Sydney Harbour",
      guestCount: "92 guests",
      style: "Modern waterfront",
      supplierCategories: ["Venues", "Photographers", "Florists / Stylists", "Entertainment / DJs"],
      imageKey: "harbour",
      label: "Example planning story",
      description: "A polished Sydney celebration shaped around water views, relaxed portraits and an evening that moved from champagne to dancing.",
      storySections: [
        "The day begins with a ceremony close to the water, keeping the styling soft so the harbour view does most of the work.",
        "Portraits are planned around golden hour, with time protected between ceremony and reception so the couple is not rushed.",
        "The reception leans modern and warm: candlelight, live music, seafood-led menus and a dance floor that opens early."
      ],
      ctaLabel: "View wedding"
    },
    {
      slug: "garden-estate-wedding",
      title: "A romantic garden estate wedding in Western Sydney",
      coupleNames: "Sophie & James",
      venue: "Garden estate inspiration",
      location: "Western Sydney",
      guestCount: "110 guests",
      style: "Romantic garden",
      supplierCategories: ["Venues", "Celebrants", "Florists / Stylists", "Caterers"],
      imageKey: "venue",
      label: "Inspired by Sydney wedding styles",
      description: "A slower, flower-filled wedding idea with lawns, family photos, long tables and plenty of breathing room between moments.",
      storySections: [
        "The ceremony is set under trees with layered florals and a celebrant who keeps the tone warm and personal.",
        "Guests move into garden drinks while family photos happen nearby, making the whole afternoon feel unhurried.",
        "The reception uses soft lighting, seasonal food and romantic flowers to keep the estate feeling intimate after dark."
      ],
      ctaLabel: "View wedding"
    },
    {
      slug: "luxury-ballroom-wedding",
      title: "A candlelit luxury ballroom wedding in the city",
      coupleNames: "Ava & Michael",
      venue: "Ballroom venue inspiration",
      location: "Sydney CBD",
      guestCount: "160 guests",
      style: "Luxury ballroom",
      supplierCategories: ["Venues", "Photographers", "Wedding Cakes", "Bridal Hair and Makeup"],
      imageKey: "reception",
      label: "Example planning story",
      description: "A formal city wedding concept with black-tie energy, layered tablescapes, a dramatic cake moment and a full dance floor.",
      storySections: [
        "The couple chooses a central venue so guests can arrive easily and the evening can feel polished from the first drink.",
        "The styling focuses on height, candlelight and rich floral texture to make a large room feel intentional.",
        "Photography is planned around city portraits, room reveals and the energy of a late-night reception."
      ],
      ctaLabel: "View wedding"
    }
  ],
  inspirationStyles: [
    {
      slug: "harbour-weddings",
      title: "Harbour weddings",
      imageKey: "harbour",
      moodDescription: "Water views, champagne light and portraits that feel unmistakably Sydney.",
      suggestedVenues: ["Zest Waterfront Venues", "Sergeants' Mess", "Gunners Barracks"],
      suggestedSupplierCategories: ["Venues", "Photographers", "Florists / Stylists"],
      tags: ["waterfront", "harbour", "modern"]
    },
    {
      slug: "garden-estate-weddings",
      title: "Garden estate weddings",
      imageKey: "venue",
      moodDescription: "Soft lawns, slower timelines and romantic florals that feel generous without being formal.",
      suggestedVenues: ["Oatlands Estate", "Gunners Barracks"],
      suggestedSupplierCategories: ["Venues", "Celebrants", "Florists / Stylists"],
      tags: ["garden", "estate", "romantic"]
    },
    {
      slug: "luxury-ballroom-weddings",
      title: "Luxury ballroom weddings",
      imageKey: "reception",
      moodDescription: "Candlelit rooms, formal styling and a reception that feels grand from the first entrance.",
      suggestedVenues: ["Doltone House"],
      suggestedSupplierCategories: ["Venues", "Wedding Cakes", "Entertainment / DJs"],
      tags: ["luxury", "ballroom", "classic"]
    },
    {
      slug: "coastal-weddings",
      title: "Coastal weddings",
      imageKey: "portrait",
      moodDescription: "Salt air, natural portraits and relaxed styling for couples drawn to Sydney's edges.",
      suggestedVenues: ["Zest Waterfront Venues", "Sergeants' Mess"],
      suggestedSupplierCategories: ["Photographers", "Celebrants", "Caterers"],
      tags: ["coastal", "relaxed", "natural"]
    },
    {
      slug: "intimate-city-weddings",
      title: "Intimate city weddings",
      imageKey: "ceremony",
      moodDescription: "Small guest lists, excellent food and a city backdrop that keeps the day easy.",
      suggestedVenues: ["Doltone House", "Gunners Barracks"],
      suggestedSupplierCategories: ["Celebrants", "Photographers", "Caterers"],
      tags: ["city", "intimate", "modern"]
    },
    {
      slug: "western-sydney-celebrations",
      title: "Western Sydney celebrations",
      imageKey: "venue",
      moodDescription: "Room for family, practical guest access and estate-style celebrations close to home.",
      suggestedVenues: ["Oatlands Estate"],
      suggestedSupplierCategories: ["Venues", "Florists / Stylists", "Entertainment / DJs"],
      tags: ["western Sydney", "family", "estate"]
    },
    {
      slug: "modern-minimalist-weddings",
      title: "Modern minimalist weddings",
      imageKey: "reception",
      moodDescription: "Clean lines, thoughtful details and styling that lets architecture and light carry the mood.",
      suggestedVenues: ["Doltone House", "Zest Waterfront Venues"],
      suggestedSupplierCategories: ["Florists / Stylists", "Photographers", "Wedding Cakes"],
      tags: ["minimal", "modern", "editorial"]
    },
    {
      slug: "romantic-floral-weddings",
      title: "Romantic floral weddings",
      imageKey: "florals",
      moodDescription: "Bouquets, ceremony flowers and tablescapes that bring softness into every part of the day.",
      suggestedVenues: ["Oatlands Estate", "Gunners Barracks"],
      suggestedSupplierCategories: ["Florists / Stylists", "Wedding Cakes", "Bridal Hair and Makeup"],
      tags: ["floral", "romantic", "soft"]
    }
  ],
  venueGuides: [
    {
      slug: "best-waterfront-wedding-venues-sydney",
      title: "Best waterfront wedding venue ideas in Sydney",
      intro: "For couples who want the water woven into the day, start with venues that make arrival, portraits and sunset drinks feel effortless.",
      imageKey: "harbour",
      venueList: ["Zest Waterfront Venues", "Sergeants' Mess", "Gunners Barracks", "Doltone House"],
      budgetNotes: "Waterfront venues often vary by date, guest count and food package. Ask for minimum spend, ceremony fees and wet-weather options.",
      faqs: [
        ["What should we ask a waterfront venue?", "Ask about ceremony backup, wind, guest arrival, sunset timing and portrait access."],
        ["Are waterfront venues always formal?", "No. Some feel relaxed and coastal, while others feel polished and black-tie."]
      ],
      internalLinks: ["/venues/sydney/", "/categories/", "/planning/questions-to-ask-wedding-venues/"]
    },
    {
      slug: "best-garden-wedding-venues-sydney",
      title: "Best garden wedding venue ideas in Sydney",
      intro: "Garden venues suit couples who want soft light, open space and a celebration that feels romantic without being rushed.",
      imageKey: "venue",
      venueList: ["Oatlands Estate", "Gunners Barracks"],
      budgetNotes: "Compare ceremony inclusions, garden access, furniture, wet-weather backup and whether styling must be hired separately.",
      faqs: [
        ["What makes a garden venue practical?", "A beautiful wet-weather plan, clear guest flow and enough shade are essential."],
        ["Do garden weddings need more styling?", "Often less than expected. Florals, linen and lighting can do most of the work."]
      ],
      internalLinks: ["/venues/", "/inspiration/garden-estate-weddings/", "/planning/how-to-choose-a-wedding-venue/"]
    },
    {
      slug: "best-western-sydney-wedding-venues",
      title: "Western Sydney wedding venue ideas",
      intro: "Western Sydney can be ideal for family-focused weddings, estate settings, easier parking and a little more room to breathe.",
      imageKey: "venue",
      venueList: ["Oatlands Estate", "Doltone House"],
      budgetNotes: "Ask about guest minimums, parking, accommodation nearby and whether the package includes coordination.",
      faqs: [
        ["Why choose Western Sydney?", "It can make travel easier for many families and offers estate-style options close to home."],
        ["What suburbs should we compare?", "Start with Parramatta, Oatlands, Penrith-adjacent areas and nearby reception centres."]
      ],
      internalLinks: ["/venues/parramatta/", "/venues/penrith/", "/inspiration/western-sydney-celebrations/"]
    },
    {
      slug: "best-small-wedding-venues-sydney",
      title: "Small wedding venue ideas in Sydney",
      intro: "A smaller wedding gives you room to focus on food, atmosphere and the people closest to you.",
      imageKey: "ceremony",
      venueList: ["Gunners Barracks", "Sergeants' Mess", "Oatlands Estate"],
      budgetNotes: "Ask about minimum guest numbers, private room hire, ceremony-only options and weekday availability.",
      faqs: [
        ["How many guests count as a small wedding?", "Many couples think of 20 to 70 guests as intimate, but it depends on the venue."],
        ["Can small weddings still feel special?", "Yes. Spend more attention on food, flowers, music and the ceremony experience."]
      ],
      internalLinks: ["/inspiration/intimate-city-weddings/", "/celebrants/", "/photographers/"]
    },
    {
      slug: "affordable-wedding-venues-sydney",
      title: "How to find a more affordable Sydney wedding venue",
      intro: "Affordable does not have to mean plain. It usually means being flexible with date, guest count and what is included.",
      imageKey: "reception",
      venueList: ["Oatlands Estate", "Doltone House", "Gunners Barracks"],
      budgetNotes: "Look at winter dates, Fridays, Sundays, lunch receptions, shorter beverage packages and venues with inclusions.",
      faqs: [
        ["What lowers venue cost fastest?", "Guest count, day of week and package inclusions usually make the biggest difference."],
        ["Should we ask for a custom quote?", "Yes. Share your date range and guest count so venues can suggest realistic options."]
      ],
      internalLinks: ["/planning/average-sydney-wedding-cost/", "/venues/", "/shortlist/"]
    },
    {
      slug: "sydney-wedding-venue-cost-guide",
      title: "Sydney wedding venue cost guide",
      intro: "Venue costs depend on date, guest count, food and beverage style, room hire and what is already included.",
      imageKey: "catering",
      venueList: ["Zest Waterfront Venues", "Doltone House", "Oatlands Estate", "Sergeants' Mess"],
      budgetNotes: "Ask every venue for the same guest count and date range. Compare minimum spend, per-head pricing, ceremony fees and overtime.",
      faqs: [
        ["Why do venue quotes vary so much?", "Packages include different food, beverage, staffing, room hire and timing details."],
        ["What should we compare first?", "Compare the total likely spend, not just the per-head price."]
      ],
      internalLinks: ["/planning/average-sydney-wedding-cost/", "/planning/questions-to-ask-wedding-venues/", "/venues/"]
    }
  ],
  planningGuides: [
    {
      slug: "average-sydney-wedding-cost",
      title: "Average Sydney wedding cost: where the money usually goes",
      intro: "A Sydney wedding budget becomes easier to manage when you separate guest-driven costs from creative supplier costs.",
      imageKey: "planningBudget",
      sections: ["Venue, food and beverage often form the largest part of the budget.", "Photography, florals, music, beauty and cake vary by style and coverage.", "Keep a contingency for transport, alterations, overtime and last-minute guest changes."],
      checklist: ["Estimate guest count", "Request venue quote", "Set supplier priorities", "Keep a 10% buffer"],
      faqs: [["How should we start a budget?", "Start with guest count and venue style, then add the suppliers that matter most to you."]],
      internalLinks: ["/venues/", "/guides/sydney-wedding-venue-cost-guide/", "/shortlist/"]
    },
    {
      slug: "how-to-choose-a-wedding-venue",
      title: "How to choose a wedding venue without second-guessing everything",
      intro: "The right venue fits your guest list, your weather plan and the way you want the day to feel.",
      imageKey: "planningVenueChoice",
      sections: ["Start with guest count and location.", "Check ceremony options, photo spots and wet-weather backup.", "Ask what is included before comparing prices."],
      checklist: ["Guest capacity", "Wet-weather plan", "Photo locations", "Transport and parking", "Package inclusions"],
      faqs: [["How many venues should we inspect?", "Three to five strong options is usually enough to make a confident choice."]],
      internalLinks: ["/venues/", "/guides/best-waterfront-wedding-venues-sydney/", "/guides/best-garden-wedding-venues-sydney/"]
    },
    {
      slug: "how-much-does-a-wedding-photographer-cost",
      title: "How much does a Sydney wedding photographer cost?",
      intro: "Photography pricing depends on coverage hours, second shooters, albums, film and delivery inclusions.",
      imageKey: "planningPhotographyCost",
      sections: ["Compare complete galleries, not only highlights.", "Ask about coverage, travel, previews and delivery timelines.", "If you want film, ask whether the team works together often."],
      checklist: ["Coverage hours", "Second shooter", "Film option", "Album", "Delivery timeline"],
      faqs: [["When should we book photography?", "As soon as your date and venue are likely, especially for peak season Saturdays."]],
      internalLinks: ["/photographers/", "/photographers/sydney/", "/inspiration/harbour-weddings/"]
    },
    {
      slug: "how-to-compare-wedding-suppliers",
      title: "How to compare wedding suppliers fairly",
      intro: "A calm shortlist compares style, availability, inclusions and communication, not just price.",
      imageKey: "planningSupplierCompare",
      sections: ["Send each supplier the same brief.", "Compare what is included and what costs extra.", "Notice who understands the mood you want."],
      checklist: ["Date availability", "Inclusions", "Travel fees", "Setup needs", "Communication style"],
      faqs: [["How many suppliers should we contact?", "Start with three favourites in each important category."]],
      internalLinks: ["/categories/", "/shortlist/", "/inspiration/"]
    },
    {
      slug: "12-month-wedding-planning-checklist",
      title: "A gentle 12-month Sydney wedding planning checklist",
      intro: "Use this as a rhythm, not a rulebook. The aim is to keep decisions moving without making every week feel urgent.",
      imageKey: "planningChecklist",
      sections: ["12 months: venue, date and guest count.", "9 months: photographer, celebrant, music and styling direction.", "6 months: catering details, cake, beauty and stationery.", "Final months: timings, RSVPs, supplier notes and payments."],
      checklist: ["Book venue", "Book photographer", "Book celebrant", "Choose styling", "Confirm timeline"],
      faqs: [["What if we have less than 12 months?", "Start with venue/date, then book the suppliers with limited availability first."]],
      internalLinks: ["/shortlist/", "/planning/questions-to-ask-wedding-venues/", "/categories/"]
    },
    {
      slug: "questions-to-ask-wedding-venues",
      title: "Questions to ask Sydney wedding venues before booking",
      intro: "Good venue questions make quotes clearer and prevent surprises later.",
      imageKey: "planningVenueQuestions",
      sections: ["Ask what happens if it rains.", "Ask what is included in the package.", "Ask about timing, bump-in, overtime, menu changes and minimum spend."],
      checklist: ["What is included?", "What is the wet-weather plan?", "What are the minimum spends?", "Can we hold ceremony and reception onsite?", "What time does music end?"],
      faqs: [["Should we ask for everything in writing?", "Yes. Keep inclusions, payment dates and timing details in one place."]],
      internalLinks: ["/venues/", "/guides/sydney-wedding-venue-cost-guide/", "/planning/how-to-choose-a-wedding-venue/"]
    }
  ]
};
