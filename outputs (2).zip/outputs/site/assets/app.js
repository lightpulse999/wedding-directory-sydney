(function () {
  const data = window.WIS_DATA;
  const root = document.documentElement;
  const pathParts = location.pathname.split("/").filter(Boolean);

  function displayCategory(category) {
    return category;
  }

  function href(path) {
    const prefix = root.dataset.depth ? "../".repeat(Number(root.dataset.depth)) : "";
    return prefix + path.replace(/^\//, "");
  }

  function image(vendorOrKey) {
    const key = typeof vendorOrKey === "string" ? vendorOrKey : vendorOrKey.imageKey;
    return data.imageLibrary[key] || data.imageLibrary.harbour;
  }

  function imageCss(vendor) {
    return `url('${image(vendor).url}')`;
  }

  function vendorUrl(vendor) {
    return href(`/vendor/${vendor.slug}/`);
  }

  function itemUrl(type, item) {
    const bases = {
      inspiration: "/inspiration/",
      realWeddings: "/real-weddings/",
      venues: "/vendor/",
      suppliers: "/vendor/",
      guides: "/guides/",
      planning: "/planning/"
    };
    return href(`${bases[type]}${item.slug}/`);
  }

  function setMeta(nameOrProperty, content, isProperty) {
    const selector = isProperty ? `meta[property="${nameOrProperty}"]` : `meta[name="${nameOrProperty}"]`;
    let tag = document.querySelector(selector);
    if (!tag) {
      tag = document.createElement("meta");
      tag.setAttribute(isProperty ? "property" : "name", nameOrProperty);
      document.head.appendChild(tag);
    }
    tag.setAttribute("content", content);
  }

  function renderMainNav() {
    document.querySelectorAll(".nav-links").forEach((nav) => {
      nav.innerHTML = [
        ["/categories/", "Vendors"],
        ["/venues/", "Venues"],
        ["/real-weddings/", "Real weddings"],
        ["/planning/", "Planning"],
        ["/about/", "About"]
      ].map(([url, label]) => `<a href="${href(url)}">${label}</a>`).join("");
    });
    document.querySelectorAll(".nav-actions").forEach((actions) => {
      actions.innerHTML = `<a class="button" href="${href("/categories/")}">Find vendors</a>`;
    });
  }

  function parseStored(key, fallback) {
    try {
      return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
    } catch {
      return fallback;
    }
  }

  function setupSaveButtons(scope) {
    (scope || document).querySelectorAll("[data-save-vendor]").forEach((button) => {
      const slug = button.dataset.saveVendor;
      const updateLabel = () => {
        const current = readSaved("suppliers");
        button.textContent = current.includes(slug) ? "Saved" : "Save";
        button.setAttribute("aria-pressed", String(current.includes(slug)));
      };
      updateLabel();
      button.addEventListener("click", () => {
        const list = readSaved("suppliers");
        const next = list.includes(slug) ? list.filter((item) => item !== slug) : [...list, slug];
        writeSaved("suppliers", next);
        updateLabel();
        renderShortlist();
        renderCompareSuppliers();
      });
    });
  }

  function readSaved(type) {
    if (type === "suppliers") {
      const modern = parseStored("wis-shortlist:suppliers", []);
      const legacy = parseStored("wis-shortlist", []);
      return Array.from(new Set([...modern, ...legacy]));
    }
    return parseStored(`wis-shortlist:${type}`, []);
  }

  function writeSaved(type, items) {
    localStorage.setItem(`wis-shortlist:${type}`, JSON.stringify(items));
    if (type === "suppliers") localStorage.setItem("wis-shortlist", JSON.stringify(items));
  }

  function setupSaveItems(scope) {
    (scope || document).querySelectorAll("[data-save-item]").forEach((button) => {
      const type = button.dataset.saveType;
      const slug = button.dataset.saveItem;
      const updateLabel = () => {
        const saved = readSaved(type);
        const isSaved = saved.includes(slug);
        button.textContent = isSaved ? "Saved" : (button.dataset.label || "Save");
        button.setAttribute("aria-pressed", String(isSaved));
      };
      updateLabel();
      button.addEventListener("click", () => {
        const saved = readSaved(type);
        const next = saved.includes(slug) ? saved.filter((item) => item !== slug) : [...saved, slug];
        writeSaved(type, next);
        updateLabel();
        renderShortlist();
        renderCompareSuppliers();
      });
    });
  }

  function setupShareButtons(scope) {
    (scope || document).querySelectorAll("[data-copy-link]").forEach((button) => {
      button.addEventListener("click", async () => {
        const url = button.dataset.copyLink || location.href;
        try {
          await navigator.clipboard.writeText(url);
          button.textContent = "Link copied";
        } catch {
          const input = document.createElement("input");
          input.value = url;
          document.body.appendChild(input);
          input.select();
          document.execCommand("copy");
          input.remove();
          button.textContent = "Link copied";
        }
      });
    });
  }

  function vendorCard(vendor) {
    const img = image(vendor);
    return `
      <article class="vendor-card">
        <a href="${vendorUrl(vendor)}" aria-label="View ${vendor.name}"><img class="vendor-media" src="${img.url}" alt="${img.alt}" loading="lazy" decoding="async"></a>
        <div class="vendor-body">
          <div class="quick-row">
            <span class="pill">${displayCategory(vendor.category)}</span>
            <span class="pill gold">${vendor.priceGuide}</span>
          </div>
          <h3>${vendor.name}</h3>
          <div class="meta">
            <span>${vendor.location}</span>
            <span>${vendor.area}</span>
            <span>${vendor.budgetFeel}</span>
          </div>
          <p>${vendor.description}</p>
          <div class="quick-row">${vendor.tags.map((tag) => `<span class="pill">${tag}</span>`).join("")}</div>
          <div class="card-footer">
            <button class="text-link" type="button" data-save-vendor="${vendor.slug}">Save</button>
            <a class="button secondary compact" href="${vendorUrl(vendor)}">View profile</a>
          </div>
        </div>
      </article>`;
  }

  function inspirationCard(item) {
    const img = image(item.imageKey);
    return `
      <article class="editorial-card pinterest-card" style="--image: url('${img.url}')">
        <div class="editorial-media" role="img" aria-label="${img.alt}"></div>
        <div class="editorial-body">
          <span class="pill gold">Inspired by Sydney wedding styles</span>
          <h3>${item.title}</h3>
          <p>${item.moodDescription}</p>
          <div class="quick-row">${item.tags.map((tag) => `<span class="pill">${tag}</span>`).join("")}</div>
          <div class="share-row">
            <a class="button secondary compact" href="${itemUrl("inspiration", item)}">Explore this style</a>
            <button class="text-link" type="button" data-save-type="inspiration" data-save-item="${item.slug}" data-label="Save">Save</button>
            <button class="text-link" type="button" data-copy-link="${itemUrl("inspiration", item)}">Copy link</button>
          </div>
        </div>
      </article>`;
  }

  function realWeddingCard(item) {
    const img = image(item.imageKey);
    return `
      <article class="editorial-card" style="--image: url('${img.url}')">
        <div class="editorial-media tall" role="img" aria-label="${img.alt}"></div>
        <div class="editorial-body">
          <span class="pill gold">${item.label}</span>
          <h3>${item.coupleNames}</h3>
          <p><strong>${item.venue}</strong> | ${item.location} | ${item.guestCount}</p>
          <p>${item.description}</p>
          <div class="quick-row"><span class="pill">${item.style}</span>${item.supplierCategories.slice(0, 3).map((cat) => `<span class="pill">${cat}</span>`).join("")}</div>
          <div class="share-row">
            <a class="button secondary compact" href="${itemUrl("realWeddings", item)}">${item.ctaLabel}</a>
            <button class="text-link" type="button" data-save-type="realWeddings" data-save-item="${item.slug}" data-label="Save">Save</button>
            <button class="text-link" type="button" data-copy-link="${itemUrl("realWeddings", item)}">Copy link</button>
          </div>
        </div>
      </article>`;
  }

  function venueShowcaseCard(vendor) {
    const img = image(vendor);
    return `
      <article class="venue-showcase-card" style="--image: ${imageCss(vendor)}">
        <div class="venue-showcase-media" role="img" aria-label="${img.alt}"></div>
        <div class="venue-showcase-body">
          <span class="pill gold">Featured Sydney venue</span>
          <h3>${vendor.name}</h3>
          <p>${vendor.location}</p>
          <div class="quick-row">${vendor.tags.slice(0, 3).map((tag) => `<span class="pill">${tag}</span>`).join("")}<span class="pill">Capacity: enquire</span><span class="pill">${vendor.priceGuide}</span></div>
          <div class="share-row">
            <a class="button secondary compact" href="${vendorUrl(vendor)}">View venue</a>
            <button class="text-link" type="button" data-save-type="venues" data-save-item="${vendor.slug}" data-label="Save">Save</button>
          </div>
        </div>
      </article>`;
  }

  function guideCard(item, type) {
    const img = image(item.imageKey);
    return `
      <article class="guide-card" style="--image: url('${img.url}')">
        <div class="guide-card-media" role="img" aria-label="${img.alt}"></div>
        <div class="guide-card-body">
          <span class="pill gold">${type === "guides" ? "Venue guide" : "Planning guide"}</span>
          <h3>${item.title}</h3>
          <p>${item.intro}</p>
          <a class="button secondary compact" href="${itemUrl(type, item)}">Read guide</a>
        </div>
      </article>`;
  }

  function renderCategories() {
    const el = document.querySelector("[data-categories]");
    if (!el) return;
    const editorialCategories = [
      ["Venues", "Harbour rooms, city landmarks and garden estates", "/venues/", "venue"],
      ["Photographers", "Editorial, documentary and quietly candid images", "/photographers/", "portrait"],
      ["Videographers", "Modern films with movement, sound and atmosphere", "/photographers/", "ceremony"],
      ["Florists", "Seasonal flowers and sculptural ceremony work", "/categories/", "florals"],
      ["Celebrants", "Personal ceremonies with warmth and clarity", "/celebrants/", "harbour"],
      ["Entertainment", "Live music, considered playlists and late nights", "/categories/", "music"],
      ["Caterers", "Menus shaped around place, season and celebration", "/categories/", "catering"],
      ["Stylists", "Tables, spaces and details with a clear point of view", "/categories/", "reception"]
    ];
    el.innerHTML = editorialCategories.map(([label, note, url, imageKey]) => `<a class="category-card" href="${href(url)}" style="--image:url('${image(imageKey).url}')">
      <span><strong>${label}</strong><span class="category-note">${note}</span></span>
    </a>`).join("");
  }

  function renderCollection(selector, items, renderer, limit) {
    const el = document.querySelector(selector);
    if (!el) return;
    el.innerHTML = items.slice(0, limit || items.length).map(renderer).join("");
    setupSaveItems(el);
    setupShareButtons(el);
  }

  function renderEditorialSections() {
    renderCollection("[data-inspiration-cards]", data.inspirationStyles, inspirationCard);
    renderCollection("[data-home-inspiration]", data.inspirationStyles, inspirationCard, 4);
    renderCollection("[data-real-wedding-cards]", data.realWeddings, realWeddingCard);
    renderCollection("[data-home-real-weddings]", data.realWeddings, realWeddingCard, 3);
    renderCollection("[data-featured-venues]", data.vendors.filter((vendor) => vendor.category === "Venues").slice(0, 4), venueShowcaseCard);
    renderCollection("[data-guide-cards]", data.venueGuides, (item) => guideCard(item, "guides"));
    renderCollection("[data-home-guide-cards]", data.venueGuides.slice(0, 3), (item) => guideCard(item, "guides"));
    renderCollection("[data-planning-guide-cards]", data.planningGuides, (item) => guideCard(item, "planning"));
  }

  function renderRealWeddingDetail() {
    const el = document.querySelector("[data-real-wedding-detail]");
    if (!el) return;
    const slug = el.dataset.realWeddingDetail || pathParts[pathParts.length - 2] || pathParts[pathParts.length - 1];
    const item = data.realWeddings.find((wedding) => wedding.slug === slug) || data.realWeddings[0];
    const img = image(item.imageKey);
    addRecentlyViewed({ type: "Example wedding", title: item.title, url: `/real-weddings/${item.slug}/` });
    document.title = `${item.title} | Wed in Sydney`;
    setMeta("description", `${item.label}: ${item.description}`, false);
    setMeta("og:title", item.title, true);
    setMeta("og:description", item.description, true);
    setMeta("og:image", img.url, true);
    el.innerHTML = `
      <section class="profile-hero">
        <div class="shell">
          <nav class="breadcrumb"><a href="${href("/")}">Home</a><span>/</span><a href="${href("/real-weddings/")}">Real Sydney weddings</a><span>/</span><span>${item.coupleNames}</span></nav>
          <div class="article-hero" style="--image:url('${img.url}')">
            <div><span class="pill gold">${item.label}</span><h1>${item.title}</h1><p class="lede">${item.description}</p></div>
          </div>
          <div class="detail-meta-grid">
            <span><strong>Couple</strong>${item.coupleNames}</span><span><strong>Venue</strong>${item.venue}</span><span><strong>Location</strong>${item.location}</span><span><strong>Guests</strong>${item.guestCount}</span><span><strong>Style</strong>${item.style}</span>
          </div>
        </div>
      </section>
      <section><div class="shell copy-grid"><div><span class="eyebrow">Planning story</span><h2>How this day could come together.</h2><div class="share-row"><button class="button secondary" type="button" data-save-type="realWeddings" data-save-item="${item.slug}" data-label="Save wedding">Save wedding</button><button class="button secondary" type="button" data-copy-link="${location.href}">Share this inspiration</button></div></div><div>${item.storySections.map((section) => `<p>${section}</p>`).join("")}<p><strong>Supplier categories:</strong> ${item.supplierCategories.join(", ")}.</p></div></div></section>
      <section><div class="shell"><div class="section-head"><div><span class="eyebrow">Similar inspiration</span><h2>Browse weddings like yours.</h2></div></div><div class="grid">${data.inspirationStyles.slice(0, 3).map(inspirationCard).join("")}</div></div></section>
      <section><div class="shell panel"><h2>Build your shortlist</h2><p>Save this story, then compare the suppliers and styles that feel closest to your own day.</p><div class="share-row"><a class="button" href="${href("/shortlist/")}">Build your shortlist</a><a class="button secondary" href="${href("/categories/")}">Browse suppliers</a></div></div></section>`;
    setupSaveItems(el);
    setupShareButtons(el);
    renderRecentlyViewed();
    injectArticleSchema(item.title, item.description, img.url);
  }

  function renderInspirationDetail() {
    const el = document.querySelector("[data-inspiration-detail]");
    if (!el) return;
    const slug = el.dataset.inspirationDetail || pathParts[pathParts.length - 2] || pathParts[pathParts.length - 1];
    const item = data.inspirationStyles.find((style) => style.slug === slug) || data.inspirationStyles[0];
    const img = image(item.imageKey);
    addRecentlyViewed({ type: "Inspiration", title: item.title, url: `/inspiration/${item.slug}/` });
    document.title = `${item.title} | Wedding Inspiration | Wed in Sydney`;
    setMeta("description", item.moodDescription, false);
    setMeta("og:title", `${item.title} | Wed in Sydney`, true);
    setMeta("og:description", item.moodDescription, true);
    setMeta("og:image", img.url, true);
    el.innerHTML = `
      <section class="profile-hero">
        <div class="shell">
          <nav class="breadcrumb"><a href="${href("/")}">Home</a><span>/</span><a href="${href("/inspiration/")}">Inspiration</a><span>/</span><span>${item.title}</span></nav>
          <div class="article-hero" style="--image:url('${img.url}')"><div><span class="pill gold">Inspired by Sydney wedding styles</span><h1>${item.title}</h1><p class="lede">${item.moodDescription}</p></div></div>
        </div>
      </section>
      <section><div class="shell guide-grid"><article class="panel"><h3>Suggested venues</h3><p>${item.suggestedVenues.join(", ")}</p></article><article class="panel"><h3>Supplier categories</h3><p>${item.suggestedSupplierCategories.join(", ")}</p></article><article class="panel"><h3>Style notes</h3><p>${item.tags.join(", ")}</p></article></div></section>
      <section><div class="shell panel"><h2>Build your shortlist</h2><p>Keep this mood in your shortlist, or copy the link to send to someone planning with you.</p><div class="share-row"><button class="button" type="button" data-save-type="inspiration" data-save-item="${item.slug}" data-label="Save inspiration">Save inspiration</button><button class="button secondary" type="button" data-copy-link="${location.href}">Share this inspiration</button><a class="button secondary" href="${href("/shortlist/")}">Build your shortlist</a><a class="button secondary" href="${href("/venues/")}">Browse venues</a></div></div></section>`;
    setupSaveItems(el);
    setupShareButtons(el);
    renderRecentlyViewed();
    injectArticleSchema(item.title, item.moodDescription, img.url);
  }

  function renderGuideDetail(kind) {
    const attr = kind === "guides" ? "data-guide-detail" : "data-planning-detail";
    const el = document.querySelector(`[${attr}]`);
    if (!el) return;
    const list = kind === "guides" ? data.venueGuides : data.planningGuides;
    const slug = el.getAttribute(attr) || pathParts[pathParts.length - 2] || pathParts[pathParts.length - 1];
    const item = list.find((guide) => guide.slug === slug) || list[0];
    const img = image(item.imageKey);
    addRecentlyViewed({ type: kind === "guides" ? "Guide" : "Planning guide", title: item.title, url: `/${kind}/${item.slug}/` });
    document.title = `${item.title} | Wed in Sydney`;
    setMeta("description", item.intro, false);
    setMeta("og:title", item.title, true);
    setMeta("og:description", item.intro, true);
    setMeta("og:image", img.url, true);
    const venueRows = (item.venueList || []).map((name) => {
      const vendor = data.vendors.find((v) => v.name === name);
      return `<tr><td>${name}</td><td>${vendor ? vendor.location : "Sydney"}</td><td>${vendor ? vendor.priceGuide : "Request quote"}</td></tr>`;
    }).join("");
    el.innerHTML = `
      <section class="profile-hero"><div class="shell"><nav class="breadcrumb"><a href="${href("/")}">Home</a><span>/</span><a href="${href(kind === "guides" ? "/guides/" : "/planning/")}">${kind === "guides" ? "Venue guides" : "Planning guides"}</a><span>/</span><span>${item.title}</span></nav><div class="article-hero" style="--image:url('${img.url}')"><div><span class="pill gold">${kind === "guides" ? "Venue guide" : "Planning guide"}</span><h1>${item.title}</h1><p class="lede">${item.intro}</p></div></div></div></section>
      <section><div class="shell copy-grid"><div><span class="eyebrow">Guide notes</span><h2>${kind === "guides" ? "Compare with context." : "Make the next decision easier."}</h2><div class="share-row"><button class="button secondary" type="button" data-copy-link="${location.href}">Copy link</button><a class="button" href="${href(kind === "guides" ? "/venues/" : "/categories/")}">${kind === "guides" ? "Browse venues" : "Browse suppliers"}</a></div></div><div>${(item.sections || [item.budgetNotes]).map((section) => `<p>${section}</p>`).join("")}${item.budgetNotes ? `<p><strong>Budget note:</strong> ${item.budgetNotes}</p>` : ""}</div></div></section>
      ${venueRows ? `<section><div class="shell"><div class="table-wrap"><table><thead><tr><th>Venue</th><th>Location</th><th>Pricing note</th></tr></thead><tbody>${venueRows}</tbody></table></div></div></section>` : ""}
      ${item.checklist ? `<section><div class="shell"><div class="section-head"><div><span class="eyebrow">Checklist</span><h2>Keep these close.</h2></div></div><div class="guide-grid">${item.checklist.map((check) => `<article class="panel"><h3>${check}</h3><p>Use this as a prompt when comparing options.</p></article>`).join("")}</div></div></section>` : ""}
      <section><div class="shell faq-grid">${item.faqs.map((faq) => `<article class="faq-item"><h3>${faq[0]}</h3><p>${faq[1]}</p></article>`).join("")}</div></section>
      <section><div class="shell panel"><h2>${kind === "guides" ? "View related suppliers" : "Keep planning"}</h2><p>${kind === "guides" ? "Use this guide as a starting point, then compare supplier profiles and direct websites." : "Open a related page or save useful ideas for later."}</p><div class="share-row"><a class="button" href="${href(kind === "guides" ? "/venues/" : "/categories/")}">${kind === "guides" ? "View related suppliers" : "Browse suppliers"}</a>${item.internalLinks.map((link) => `<a class="button secondary" href="${href(link)}">Explore</a>`).join("")}</div></div></section>
      <section><div class="shell panel"><h2>Recently viewed</h2><div data-recently-viewed></div></div></section>`;
    setupShareButtons(el);
    renderRecentlyViewed();
    injectArticleSchema(item.title, item.intro, img.url);
    injectCustomFaqSchema(item.faqs);
  }

  function setupSearch() {
    const form = document.querySelector("[data-search-form]");
    if (!form) return;
    const input = form.querySelector("[data-search-input]");
    const category = form.querySelector("[data-category-filter]");
    const style = form.querySelector("[data-style-filter]");
    const area = form.querySelector("[data-area-filter]");
    const budgetFeel = form.querySelector("[data-budget-feel-filter]");
    const output = document.querySelector("[data-search-results]");
    const summary = document.querySelector("[data-result-summary]");
    const baseCategory = form.dataset.baseCategory || "all";
    const baseLocation = form.dataset.baseLocation || "";
    const initialLimit = Number(form.dataset.initialLimit || 0);

    function matchesText(vendor, q) {
      if (!q) return true;
      return [
        vendor.name,
        vendor.category,
        vendor.location,
        vendor.description,
        vendor.tags.join(" "),
        vendor.services.join(" "),
        vendor.areasServiced.join(" ")
      ].join(" ").toLowerCase().includes(q);
    }

    function matchesLocation(vendor) {
      if (!baseLocation || baseLocation === "sydney") return true;
      if (["parramatta", "northern"].includes(baseLocation) && /sydney-wide|greater sydney|sydney|nsw/i.test(vendor.areasServiced.join(" "))) return true;
      return `${vendor.location} ${vendor.areasServiced.join(" ")}`.toLowerCase().includes(baseLocation);
    }

    function update() {
      const q = input ? input.value.trim().toLowerCase() : "";
      const selectedCategory = category ? category.value : baseCategory;
      const selectedStyle = style ? style.value : "all";
      const selectedArea = area ? area.value : "all";
      const selectedBudgetFeel = budgetFeel ? budgetFeel.value : "all";
      const filtered = data.vendors
        .filter((vendor) => selectedCategory === "all" || vendor.category === selectedCategory)
        .filter((vendor) => selectedArea === "all" || vendor.area === selectedArea)
        .filter((vendor) => selectedBudgetFeel === "all" || vendor.budgetFeel === selectedBudgetFeel)
        .filter(matchesLocation)
        .filter((vendor) => selectedStyle === "all" || selectedStyle === "0" || vendor.tags.includes(selectedStyle))
        .filter((vendor) => matchesText(vendor, q))
        .sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
      const isDefault = !q && selectedCategory === "all" && selectedStyle === "all" && selectedArea === "all" && selectedBudgetFeel === "all";
      const featuredSlugs = ["zest-waterfront-venues", "gunners-barracks", "salt-atelier", "celebrant-melissa-soncini", "melissa-d-cruz-floral", "the-white-tree"];
      const visible = initialLimit && isDefault
        ? featuredSlugs.map((slug) => data.vendors.find((vendor) => vendor.slug === slug)).filter(Boolean).slice(0, initialLimit)
        : filtered;
      if (output) {
        output.innerHTML = visible.map(vendorCard).join("");
        setupSaveButtons(output);
      }
      if (summary) {
        summary.textContent = isDefault && initialLimit
          ? "A considered selection of Sydney wedding professionals."
          : `${filtered.length} vendor${filtered.length === 1 ? "" : "s"} found.`;
      }
    }

    form.addEventListener("submit", (event) => { event.preventDefault(); update(); });
    [input, category, style, area, budgetFeel].forEach((field) => field && field.addEventListener("input", update));
    document.querySelectorAll("[data-shortcut]").forEach((button) => {
      button.addEventListener("click", () => {
        if (category) category.value = button.dataset.shortcut;
        update();
        document.querySelector("#vendors")?.scrollIntoView({ behavior: "smooth" });
      });
    });
    update();
  }

  function setupTools() {
    const budgetInputs = document.querySelectorAll("[data-budget]");
    const result = document.querySelector("[data-budget-result]");
    const breakdown = document.querySelector("[data-budget-breakdown]");
    function updateBudget() {
      if (!result) return;
      const guests = Number(document.querySelector("[data-budget='guests']")?.value || 90);
      const perHead = Number(document.querySelector("[data-budget='perHead']")?.value || 220);
      const extras = Number(document.querySelector("[data-budget='extras']")?.value || 12000);
      const total = guests * perHead + extras;
      result.textContent = `A gentle starting estimate: $${total.toLocaleString("en-AU")}`;
      if (breakdown) {
        const venue = guests * perHead;
        const allocations = [
          ["Venue / catering", venue],
          ["Photography", Math.round(extras * 0.22)],
          ["Celebrant", Math.round(extras * 0.08)],
          ["Florals / styling", Math.round(extras * 0.18)],
          ["Entertainment", Math.round(extras * 0.14)],
          ["Cake", Math.round(extras * 0.06)],
          ["Hair and makeup", Math.round(extras * 0.12)],
          ["Contingency", Math.round(total * 0.1)]
        ];
        breakdown.innerHTML = allocations.map(([label, value]) => `<li><span>${label}</span><strong>$${value.toLocaleString("en-AU")}</strong></li>`).join("");
      }
    }
    budgetInputs.forEach((field) => field.addEventListener("input", updateBudget));
    updateBudget();

    document.querySelectorAll("[data-check]").forEach((box) => {
      const key = `wis-check-${box.value}`;
      box.checked = localStorage.getItem(key) === "true";
      box.addEventListener("change", () => localStorage.setItem(key, box.checked));
    });
  }

  function setupStyleFinder() {
    const form = document.querySelector("[data-style-finder]");
    if (!form) return;
    const output = form.querySelector("[data-style-finder-result]");
    const update = () => {
      const setting = form.querySelector("[name='setting']")?.value || "Harbour";
      const guests = form.querySelector("[name='guests']")?.value || "60-120";
      const budget = form.querySelector("[name='budget']")?.value || "Mid-range";
      const recommendation = data.styleFinder.recommendations[setting] || data.styleFinder.recommendations.Harbour;
      output.innerHTML = `
        <strong>${setting} wedding direction</strong>
        <p>${recommendation[0]} For ${guests.toLowerCase()} guests with a ${budget.toLowerCase()} feel, shortlist a venue first, then compare photography, celebrant and styling options.</p>
        <div class="share-row"><a class="button secondary compact" href="${href(recommendation[1])}">Explore this style</a><a class="button secondary compact" href="${href(recommendation[2])}">View next step</a></div>`;
    };
    form.addEventListener("input", update);
    update();
  }

  function viewedItems() {
    return parseStored("wis-recently-viewed", []);
  }

  function addRecentlyViewed(item) {
    const next = [item, ...viewedItems().filter((entry) => entry.url !== item.url)].slice(0, 6);
    localStorage.setItem("wis-recently-viewed", JSON.stringify(next));
  }

  function renderRecentlyViewed() {
    const targets = document.querySelectorAll("[data-recently-viewed]");
    if (!targets.length) return;
    const items = viewedItems();
    targets.forEach((el) => {
      el.innerHTML = items.length ? `
        <div class="compare-list light">
          ${items.map((item) => `<article><strong>${item.title}</strong><span>${item.type}</span><a class="text-link" href="${href(item.url)}">Open</a></article>`).join("")}
        </div>` : "<p>Recently viewed suppliers, guides and inspiration will appear here.</p>";
    });
  }

  function renderCompareSuppliers() {
    const el = document.querySelector("[data-compare-suppliers]");
    if (!el) return;
    const vendors = readSaved("suppliers")
      .map((slug) => data.vendors.find((vendor) => vendor.slug === slug))
      .filter(Boolean)
      .slice(0, 3);
    if (!vendors.length) {
      el.innerHTML = "<p>Save up to three suppliers to compare location, style, services and website links here.</p>";
      return;
    }
    el.innerHTML = `
      <div class="table-wrap compare-table"><table><thead><tr><th>Supplier</th><th>Location</th><th>Style</th><th>Price note</th><th>Services</th><th>Website</th></tr></thead><tbody>
      ${vendors.map((vendor) => `<tr><td>${vendor.name}<br><small>${vendor.category}</small></td><td>${vendor.location}</td><td>${vendor.tags.slice(0, 3).join(", ")}</td><td>${vendor.priceGuide}</td><td>${vendor.services.slice(0, 3).join(", ")}</td><td><a class="text-link" href="${vendor.websiteUrl}" target="_blank" rel="noreferrer">Visit</a></td></tr>`).join("")}
      </tbody></table></div>`;
  }

  function renderShortlist() {
    const el = document.querySelector("[data-shortlist]");
    if (!el) return;
    const supplierSlugs = readSaved("suppliers");
    const venueSlugs = readSaved("venues");
    const inspirationSlugs = readSaved("inspiration");
    const weddingSlugs = readSaved("realWeddings");
    const vendors = supplierSlugs
      .map((slug) => data.vendors.find((vendor) => vendor.slug === slug))
      .filter(Boolean);
    const venues = venueSlugs
      .map((slug) => data.vendors.find((vendor) => vendor.slug === slug))
      .filter(Boolean);
    const inspiration = inspirationSlugs
      .map((slug) => data.inspirationStyles.find((item) => item.slug === slug))
      .filter(Boolean);
    const weddings = weddingSlugs
      .map((slug) => data.realWeddings.find((item) => item.slug === slug))
      .filter(Boolean);

    if (![vendors, venues, inspiration, weddings].some((items) => items.length)) {
      el.innerHTML = `
        <p>Save suppliers, venues, inspiration styles or example weddings and they will appear here for an easy side-by-side check.</p>
        <p class="tool-result">Your shortlist is empty for now.</p>`;
      return;
    }

    const supplierGroup = (title, items) => items.length ? `
      <section class="shortlist-group"><h2>${title}</h2><div class="compare-list">
        ${items.map((vendor) => `
          <article>
            <strong>${vendor.name}</strong>
            <span>${vendor.category}</span>
            <span>${vendor.location}</span>
            <a class="text-link" href="${vendorUrl(vendor)}">View profile</a>
          </article>
        `).join("")}
      </div></section>` : "";
    const editorialGroup = (title, items, type) => items.length ? `
      <section class="shortlist-group"><h2>${title}</h2><div class="compare-list">
        ${items.map((item) => `
          <article>
            <strong>${item.title || item.coupleNames}</strong>
            <span>${item.style || item.moodDescription}</span>
            <a class="text-link" href="${itemUrl(type, item)}">Open</a>
          </article>
        `).join("")}
      </div></section>` : "";

    el.innerHTML = [
      supplierGroup("Suppliers", vendors),
      supplierGroup("Venues", venues),
      editorialGroup("Inspiration", inspiration, "inspiration"),
      editorialGroup("Real wedding examples", weddings, "realWeddings")
    ].join("");
  }

  function promptsForVendor(vendor) {
    return data.questionPrompts[vendor.category] || data.questionPrompts.default;
  }

  function relatedLinksForVendor(vendor) {
    if (vendor.category === "Venues") return [
      ["/guides/sydney-wedding-venue-cost-guide/", "Venue cost guide"],
      ["/planning/questions-to-ask-wedding-venues/", "Questions to ask venues"],
      ["/inspiration/harbour-weddings/", "Harbour inspiration"]
    ];
    if (vendor.category === "Photographers") return [
      ["/planning/how-much-does-a-wedding-photographer-cost/", "Photography cost guide"],
      ["/real-weddings/harbour-wedding-sydney/", "Harbour story"],
      ["/celebrants/", "Browse celebrants"]
    ];
    return [
      ["/planning/how-to-compare-wedding-suppliers/", "Compare suppliers"],
      ["/inspiration/", "Browse inspiration"],
      ["/shortlist/", "Open shortlist"]
    ];
  }

  function nextStepForVendor(vendor) {
    if (vendor.category === "Venues") return ["Save venue", "/photographers/", "Browse photographers"];
    if (vendor.category === "Photographers") return ["Save photographer", "/celebrants/", "Browse celebrants"];
    return ["Save supplier", "/shortlist/", "Build your shortlist"];
  }

  function renderProfile() {
    const el = document.querySelector("[data-profile]");
    if (!el) return;
    const lastPathPart = pathParts[pathParts.length - 1];
    const slug = el.dataset.profile || (lastPathPart === "index.html" ? pathParts[pathParts.length - 2] : lastPathPart);
    const vendor = data.vendors.find((item) => item.slug === slug) || data.vendors[0];
    const similar = data.vendors.filter((item) => item.category === vendor.category && item.slug !== vendor.slug).slice(0, 3);
    const mainImage = image(vendor);
    const gallery = [vendor.imageKey, "harbour", "reception"].map((key) => image(key));
    const relatedLinks = relatedLinksForVendor(vendor);
    const nextStep = nextStepForVendor(vendor);
    const saveControl = vendor.category === "Venues"
      ? `data-save-type="venues" data-save-item="${vendor.slug}" data-label="${nextStep[0]}"`
      : `data-save-vendor="${vendor.slug}"`;
    addRecentlyViewed({ type: "Supplier", title: vendor.name, url: `/vendor/${vendor.slug}/` });

    document.title = `${vendor.name} | ${displayCategory(vendor.category)} in ${vendor.location} | Wed in Sydney`;
    const metaDescription = `${vendor.name} is a ${displayCategory(vendor.category).toLowerCase()} supplier serving ${vendor.location}. Compare services, areas serviced and request pricing.`;
    setMeta("description", metaDescription, false);
    setMeta("og:title", `${vendor.name} | Wed in Sydney`, true);
    setMeta("og:description", metaDescription, true);
    setMeta("og:image", mainImage.url, true);
    setMeta("twitter:card", "summary_large_image", false);
    const businessSchema = document.createElement("script");
    businessSchema.type = "application/ld+json";
    businessSchema.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": vendor.name,
      "url": vendor.websiteUrl,
      "image": mainImage.url,
      "address": {
        "@type": "PostalAddress",
        "addressLocality": vendor.location,
        "addressRegion": "NSW",
        "addressCountry": "AU"
      }
    });
    document.head.appendChild(businessSchema);

    el.innerHTML = `
      <section class="profile-hero">
        <div class="shell">
          <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="${href("/")}">Home</a><span>/</span><a href="${href("/categories/")}">Categories</a><span>/</span><span>${vendor.name}</span>
          </nav>
          <div class="profile-grid">
            <div>
              <div class="gallery">
                <img src="${gallery[0].url}" alt="${gallery[0].alt}">
                <div>
                  <img src="${gallery[1].url}" alt="${gallery[1].alt}">
                  <img src="${gallery[2].url}" alt="${gallery[2].alt}" style="margin-top:12px">
                </div>
              </div>
              <section>
                <span class="eyebrow">Supplier profile</span>
                <h1>${vendor.name}</h1>
                <p class="lede">${vendor.description} Save this supplier, explore similar options and ask about availability when the fit feels right.</p>
                <div class="quick-row">
                  <span class="pill">${displayCategory(vendor.category)}</span>
                  <span class="pill">${vendor.location}</span>
                  <span class="pill">${vendor.area}</span>
                  <span class="pill">${vendor.budgetFeel}</span>
                  <span class="pill gold">${vendor.priceGuide}</span>
                </div>
              </section>
            </div>
            <aside class="profile-card" id="contact">
              <h3>Enquire with this supplier</h3>
              <p>Ask about availability, packages and pricing. Share your date, guest count and what you love about their style.</p>
              <form class="form-grid" action="mailto:hello@wedinsydney.com" method="post" enctype="text/plain">
                <label>Your name<input name="name" required></label>
                <label>Email<input type="email" name="email" required></label>
                <label>Wedding date<input type="date" name="date"></label>
                <label>Message<textarea name="message" placeholder="Tell them your date, guest count and the kind of celebration you are planning."></textarea></label>
                <button class="button" type="submit">Enquire with this supplier</button>
                <button class="button secondary" type="button" ${saveControl}>${nextStep[0]}</button>
                <a class="text-link external-link" href="${vendor.websiteUrl}" target="_blank" rel="noreferrer">Visit supplier website</a>
              </form>
            </aside>
          </div>
        </div>
      </section>
      <section>
        <div class="shell guide-grid">
          <article class="panel"><h3>Services offered</h3><ul class="service-list">${vendor.services.map((item) => `<li>${item}</li>`).join("")}</ul></article>
          <article class="panel"><h3>Areas serviced</h3><p>${vendor.areasServiced.join(", ")}.</p></article>
          <article class="panel"><h3>Notes for couples</h3><p>Public supplier information. Use this as a starting point for your own research, then visit the supplier website to confirm availability, packages and details.</p><p>${vendor.reviewNote}. ${vendor.priceGuide}.</p></article>
        </div>
      </section>
      <section>
        <div class="shell">
          <div class="section-head"><div><span class="eyebrow">Questions to ask</span><h2>Send a more useful enquiry.</h2><p>These prompts help you compare suppliers without needing exact prices upfront.</p></div></div>
          <div class="guide-grid">${promptsForVendor(vendor).map((question) => `<article class="faq-item"><h3>${question}</h3><p>Add this to your enquiry if it matters for your date, guest count or wedding style.</p></article>`).join("")}</div>
        </div>
      </section>
      <section>
        <div class="shell guide-grid">
          <article class="panel"><h3>Helpful links</h3><div class="compare-list light">${relatedLinks.map(([url, label]) => `<article><strong>${label}</strong><a class="text-link" href="${href(url)}">Open</a></article>`).join("")}</div></article>
          <article class="panel"><h3>Recently viewed</h3><div data-recently-viewed></div></article>
          <article class="panel"><h3>Next step</h3><p>Keep this supplier close, then compare the next part of your day.</p><div class="share-row"><button class="button secondary" type="button" ${saveControl}>${nextStep[0]}</button><a class="button" href="${href(nextStep[1])}">${nextStep[2]}</a></div></article>
        </div>
      </section>
      <section>
        <div class="shell">
          <div class="section-head"><div><span class="eyebrow">Similar suppliers</span><h2>Keep shaping your shortlist.</h2></div></div>
          <div class="grid">${similar.map(vendorCard).join("")}</div>
        </div>
      </section>`;
    setupSaveButtons(el);
    setupSaveItems(el);
    renderRecentlyViewed();
  }

  function injectFaqSchema() {
    const faq = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How should we compare Sydney wedding suppliers?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Start with the style of celebration you want, then compare location, services, pricing notes and availability before sending enquiries."
          }
        },
        {
          "@type": "Question",
          "name": "Can we request pricing?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes. Supplier profiles include enquiry prompts so couples can ask about packages, availability and pricing."
          }
        }
      ]
    };
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(faq);
    document.head.appendChild(script);
  }

  function injectBreadcrumbSchema() {
    const crumbs = Array.from(document.querySelectorAll(".breadcrumb a, .breadcrumb span"))
      .map((node) => node.textContent.trim())
      .filter((text) => text && text !== "/");
    if (!crumbs.length) return;
    const schema = {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": crumbs.map((name, index) => ({
        "@type": "ListItem",
        "position": index + 1,
        "name": name
      }))
    };
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(schema);
    document.head.appendChild(script);
  }

  function injectArticleSchema(title, description, imageUrl) {
    const schema = {
      "@context": "https://schema.org",
      "@type": "Article",
      "headline": title,
      "description": description,
      "image": imageUrl,
      "author": {
        "@type": "Organization",
        "name": "Wed in Sydney"
      }
    };
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(schema);
    document.head.appendChild(script);
  }

  function injectCustomFaqSchema(faqs) {
    if (!faqs || !faqs.length) return;
    const schema = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": faqs.map((faq) => ({
        "@type": "Question",
        "name": faq[0],
        "acceptedAnswer": {
          "@type": "Answer",
          "text": faq[1]
        }
      }))
    };
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(schema);
    document.head.appendChild(script);
  }

  renderMainNav();
  renderCategories();
  setupSearch();
  setupTools();
  setupStyleFinder();
  renderEditorialSections();
  renderRealWeddingDetail();
  renderInspirationDetail();
  renderGuideDetail("guides");
  renderGuideDetail("planning");
  renderProfile();
  setupSaveButtons(document);
  setupSaveItems(document);
  setupShareButtons(document);
  renderShortlist();
  renderCompareSuppliers();
  renderRecentlyViewed();
  injectFaqSchema();
  injectBreadcrumbSchema();
})();
