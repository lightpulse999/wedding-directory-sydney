(function () {
  const data = window.WIS_DATA;
  const root = document.documentElement;
  const pathParts = location.pathname.split("/").filter(Boolean);

  function displayCategory(category) {
    return category;
  }

  function href(path) {
    const prefix = root.dataset.depth ? "../".repeat(Number(root.dataset.depth)) : "";
    return prefix + path.replace(/^\//, "");
  }

  function image(vendorOrKey) {
    const key = typeof vendorOrKey === "string" ? vendorOrKey : vendorOrKey.imageKey;
    return data.imageLibrary[key] || data.imageLibrary.harbour;
  }

  function imageCss(vendor) {
    return `url('${image(vendor).url}')`;
  }

  function verifiedWebsiteUrl(vendor) {
    return vendor.websiteVerified === true && vendor.websiteUrl ? vendor.websiteUrl : "";
  }

  function vendorWebsiteCta(vendor, className = "button secondary") {
    const url = verifiedWebsiteUrl(vendor);
    return url
      ? `<a class="${className}" href="${url}" target="_blank" rel="noopener noreferrer">Visit website</a>`
      : `<span class="${className} is-disabled" aria-disabled="true">Website coming soon</span>`;
  }

  function vendorUrl(vendor) {
    return `#vendor=${encodeURIComponent(vendor.slug)}`;
  }

  function compareItems() {
    return parseStored("wis-compare", []);
  }

  function writeCompare(items) {
    localStorage.setItem("wis-compare", JSON.stringify(items.slice(0, 3)));
  }

  function itemUrl(type, item) {
    const bases = {
      inspiration: "/inspiration/",
      realWeddings: "/real-weddings/",
      venues: "/vendor/",
      suppliers: "/vendor/",
      guides: "/guides/",
      planning: "/planning/"
    };
    return href(`${bases[type]}${item.slug}/`);
  }

  function setMeta(nameOrProperty, content, isProperty) {
    const selector = isProperty ? `meta[property="${nameOrProperty}"]` : `meta[name="${nameOrProperty}"]`;
    let tag = document.querySelector(selector);
    if (!tag) {
      tag = document.createElement("meta");
      tag.setAttribute(isProperty ? "property" : "name", nameOrProperty);
      document.head.appendChild(tag);
    }
    tag.setAttribute("content", content);
  }

  function renderMainNav() {
    document.querySelectorAll(".nav-links").forEach((nav) => {
      nav.innerHTML = [
        ["/categories/", "Vendors"],
        ["/venues/", "Venues"],
        ["/planning/", "Planning"],
        ["/about/", "About"]
      ].map(([url, label]) => {
        const active = url !== "/" && location.pathname.startsWith(url);
        return `<a href="${href(url)}"${active ? ' aria-current="page"' : ""}>${label}</a>`;
      }).join("");
    });
    document.querySelectorAll(".nav-actions").forEach((actions) => {
      actions.innerHTML = `<a class="button" href="${href("/categories/")}">Find vendors</a>`;
    });
    document.querySelectorAll(".nav").forEach((nav) => {
      if (nav.querySelector(".nav-toggle")) return;
      const toggle = document.createElement("button");
      toggle.className = "nav-toggle";
      toggle.type = "button";
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Open navigation");
      toggle.innerHTML = "<span></span><span></span>";
      nav.querySelector(".brand")?.after(toggle);
      toggle.addEventListener("click", () => {
        const open = nav.classList.toggle("menu-open");
        toggle.setAttribute("aria-expanded", String(open));
        toggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
      });
      nav.querySelectorAll(".nav-links a").forEach((link) => link.addEventListener("click", () => {
        nav.classList.remove("menu-open");
        toggle.setAttribute("aria-expanded", "false");
      }));
    });
  }

  function enhanceFooterLinks() {
    document.querySelectorAll("footer .footer-row").forEach((row) => {
      const linkArea = row.lastElementChild;
      if (!linkArea || linkArea.querySelector('a[href*="contact"]')) return;
      [
        ["/contact/", "Contact"],
        ["/privacy/", "Privacy"],
        ["/terms/", "Terms"]
      ].forEach(([url, label]) => {
        const link = document.createElement("a");
        link.href = href(url);
        link.textContent = label;
        linkArea.appendChild(link);
      });
    });
  }

  function parseStored(key, fallback) {
    try {
      return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
    } catch {
      return fallback;
    }
  }

  function setupSaveButtons(scope) {
    (scope || document).querySelectorAll("[data-save-vendor]").forEach((button) => {
      const slug = button.dataset.saveVendor;
      const updateLabel = () => {
        const current = readSaved("suppliers");
        button.textContent = current.includes(slug) ? "Saved" : "Save";
        button.setAttribute("aria-pressed", String(current.includes(slug)));
      };
      updateLabel();
      button.addEventListener("click", () => {
        const list = readSaved("suppliers");
        const next = list.includes(slug) ? list.filter((item) => item !== slug) : [...list, slug];
        writeSaved("suppliers", next);
        updateLabel();
        renderShortlist();
        renderCompareSuppliers();
      });
    });
  }

  function announce(message) {
    let toast = document.querySelector("[data-toast]");
    if (!toast) {
      toast = document.createElement("div");
      toast.className = "toast";
      toast.dataset.toast = "";
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-live", "polite");
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(announce.timer);
    announce.timer = setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function setupCompareButtons(scope) {
    (scope || document).querySelectorAll("[data-compare-vendor]").forEach((button) => {
      if (button.dataset.compareBound) return;
      button.dataset.compareBound = "true";
      const slug = button.dataset.compareVendor;
      const updateLabel = () => {
        const selected = compareItems().includes(slug);
        button.textContent = selected ? "Comparing" : "Compare";
        button.setAttribute("aria-pressed", String(selected));
      };
      updateLabel();
      button.addEventListener("click", () => {
        const current = compareItems();
        const selected = current.includes(slug);
        if (!selected && current.length >= 3) {
          announce("You can compare up to three vendors. Remove one first.");
          return;
        }
        writeCompare(selected ? current.filter((item) => item !== slug) : [...current, slug]);
        document.querySelectorAll(`[data-compare-vendor="${slug}"]`).forEach((control) => {
          control.textContent = selected ? "Compare" : "Comparing";
          control.setAttribute("aria-pressed", String(!selected));
        });
        renderCompareSuppliers();
        renderCompareTray();
        announce(selected ? "Removed from comparison." : "Added to comparison.");
      });
    });
  }

  function renderCompareTray() {
    let tray = document.querySelector("[data-compare-tray]");
    const count = compareItems().length;
    if (!count) {
      tray?.remove();
      return;
    }
    if (!tray) {
      tray = document.createElement("aside");
      tray.className = "compare-tray";
      tray.dataset.compareTray = "";
      document.body.appendChild(tray);
    }
    tray.innerHTML = `<span><strong>${count}</strong> of 3 selected</span><a class="button compact" href="${href("/shortlist/")}#compare">Compare vendors</a>`;
  }

  function vendorModalMarkup(vendor) {
    const img = image(vendor);
    return `<div class="vendor-modal-grid">
      <div class="vendor-modal-media"><img src="${img.url}" alt="${img.alt}"></div>
      <div class="vendor-modal-copy">
        <button class="modal-close" type="button" data-modal-close aria-label="Close vendor profile">Close</button>
        <span class="eyebrow">${displayCategory(vendor.category)}</span>
        <h2>${vendor.name}</h2>
        <p class="modal-location">${vendor.location} · ${vendor.priceGuide}</p>
        <p>${vendor.description}</p>
        <h3>Services offered</h3>
        <ul class="modal-service-list">${vendor.services.map((service) => `<li>${service}</li>`).join("")}</ul>
        <div class="modal-actions">
          ${vendorWebsiteCta(vendor, "button")}
          <button class="button secondary" type="button" data-save-vendor="${vendor.slug}">Save</button>
          <button class="button secondary" type="button" data-compare-vendor="${vendor.slug}">Compare</button>
        </div>
      </div>
    </div>`;
  }

  function ensureVendorModal() {
    let dialog = document.querySelector("[data-vendor-modal]");
    if (dialog) return dialog;
    dialog = document.createElement("dialog");
    dialog.className = "vendor-modal";
    dialog.dataset.vendorModal = "";
    dialog.setAttribute("aria-label", "Vendor profile");
    document.body.appendChild(dialog);
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog || event.target.closest("[data-modal-close]")) closeVendorModal();
    });
    dialog.addEventListener("cancel", (event) => {
      event.preventDefault();
      closeVendorModal();
    });
    return dialog;
  }

  function openVendorModal(slug, trigger) {
    const vendor = data.vendors.find((item) => item.slug === slug);
    if (!vendor) {
      announce("That vendor profile is not available yet.");
      return;
    }
    const dialog = ensureVendorModal();
    dialog.innerHTML = vendorModalMarkup(vendor);
    dialog.dataset.opener = trigger?.dataset.vendorOpen || "";
    setupSaveButtons(dialog);
    setupCompareButtons(dialog);
    addRecentlyViewed({ type: "Supplier", title: vendor.name, url: `#vendor=${vendor.slug}` });
    if (!dialog.open) dialog.showModal();
    document.body.classList.add("modal-open");
    dialog.querySelector("[data-modal-close]")?.focus();
  }

  function closeVendorModal() {
    const dialog = document.querySelector("[data-vendor-modal]");
    if (!dialog?.open) return;
    dialog.close();
    document.body.classList.remove("modal-open");
    if (location.hash.startsWith("#vendor=")) history.replaceState(null, "", `${location.pathname}${location.search}`);
  }

  function setupVendorInteractions(scope) {
    if (!root.dataset.vendorDelegated) {
      root.dataset.vendorDelegated = "true";
      document.addEventListener("click", (event) => {
        const link = event.target.closest("[data-vendor-open]");
        if (!link) return;
        event.preventDefault();
        const slug = link.dataset.vendorOpen;
        history.pushState(null, "", `#vendor=${encodeURIComponent(slug)}`);
        openVendorModal(slug, link);
      });
    }
    setupCompareButtons(scope);
  }

  function readSaved(type) {
    if (type === "suppliers") {
      const modern = parseStored("wis-shortlist:suppliers", []);
      const legacy = parseStored("wis-shortlist", []);
      return Array.from(new Set([...modern, ...legacy]));
    }
    return parseStored(`wis-shortlist:${type}`, []);
  }

  function writeSaved(type, items) {
    localStorage.setItem(`wis-shortlist:${type}`, JSON.stringify(items));
    if (type === "suppliers") localStorage.setItem("wis-shortlist", JSON.stringify(items));
  }

  function setupSaveItems(scope) {
    (scope || document).querySelectorAll("[data-save-item]").forEach((button) => {
      const type = button.dataset.saveType;
      const slug = button.dataset.saveItem;
      const updateLabel = () => {
        const saved = readSaved(type);
        const isSaved = saved.includes(slug);
        button.textContent = isSaved ? "Saved" : (button.dataset.label || "Save");
        button.setAttribute("aria-pressed", String(isSaved));
      };
      updateLabel();
      button.addEventListener("click", () => {
        const saved = readSaved(type);
        const next = saved.includes(slug) ? saved.filter((item) => item !== slug) : [...saved, slug];
        writeSaved(type, next);
        updateLabel();
        renderShortlist();
        renderCompareSuppliers();
      });
    });
  }

  function setupShareButtons(scope) {
    (scope || document).querySelectorAll("[data-copy-link]").forEach((button) => {
      button.addEventListener("click", async () => {
        const url = button.dataset.copyLink || location.href;
        try {
          await navigator.clipboard.writeText(url);
          button.textContent = "Link copied";
        } catch {
          const input = document.createElement("input");
          input.value = url;
          document.body.appendChild(input);
          input.select();
          document.execCommand("copy");
          input.remove();
          button.textContent = "Link copied";
        }
      });
    });
  }

  function vendorCard(vendor) {
    const img = image(vendor);
    return `
      <article class="vendor-card">
        <a href="${vendorUrl(vendor)}" data-vendor-open="${vendor.slug}" aria-label="View ${vendor.name}"><img class="vendor-media" src="${img.url}" alt="${img.alt}" loading="lazy" decoding="async"></a>
        <div class="vendor-body">
          <div class="quick-row">
            <span class="pill">${displayCategory(vendor.category)}</span>
            <span class="pill gold">${vendor.priceGuide}</span>
          </div>
          <h3>${vendor.name}</h3>
          <div class="meta">
            <span>${vendor.location}</span>
            <span>${vendor.area}</span>
            <span>${vendor.budgetFeel}</span>
          </div>
          <p>${vendor.description}</p>
          <div class="quick-row">${vendor.tags.map((tag) => `<span class="pill">${tag}</span>`).join("")}</div>
          <div class="card-footer">
            <button class="text-link" type="button" data-save-vendor="${vendor.slug}">Save</button>
            <button class="text-link" type="button" data-compare-vendor="${vendor.slug}">Compare</button>
            <a class="button secondary compact" href="${vendorUrl(vendor)}" data-vendor-open="${vendor.slug}">View profile</a>
          </div>
        </div>
      </article>`;
  }

  function inspirationCard(item) {
    const img = image(item.imageKey);
    return `
      <article class="editorial-card pinterest-card" style="--image: url('${img.url}')">
        <div class="editorial-media" role="img" aria-label="${img.alt}"></div>
        <div class="editorial-body">
          <span class="pill gold">Inspired by Sydney wedding styles</span>
          <h3>${item.title}</h3>
          <p>${item.moodDescription}</p>
          <div class="quick-row">${item.tags.map((tag) => `<span class="pill">${tag}</span>`).join("")}</div>
          <div class="share-row">
            <a class="button secondary compact" href="${itemUrl("inspiration", item)}">Explore this style</a>
            <button class="text-link" type="button" data-save-type="inspiration" data-save-item="${item.slug}" data-label="Save">Save</button>
            <button class="text-link" type="button" data-copy-link="${itemUrl("inspiration", item)}">Copy link</button>
          </div>
        </div>
      </article>`;
  }

  function realWeddingCard(item) {
    const img = image(item.imageKey);
    return `
      <article class="editorial-card" style="--image: url('${img.url}')">
        <div class="editorial-media tall" role="img" aria-label="${img.alt}"></div>
        <div class="editorial-body">
          <span class="pill gold">${item.label}</span>
          <h3>${item.coupleNames}</h3>
          <p><strong>${item.venue}</strong> | ${item.location} | ${item.guestCount}</p>
          <p>${item.description}</p>
          <div class="quick-row"><span class="pill">${item.style}</span>${item.supplierCategories.slice(0, 3).map((cat) => `<span class="pill">${cat}</span>`).join("")}</div>
          <div class="share-row">
            <a class="button secondary compact" href="${itemUrl("realWeddings", item)}">${item.ctaLabel}</a>
            <button class="text-link" type="button" data-save-type="realWeddings" data-save-item="${item.slug}" data-label="Save">Save</button>
            <button class="text-link" type="button" data-copy-link="${itemUrl("realWeddings", item)}">Copy link</button>
          </div>
        </div>
      </article>`;
  }

  function venueShowcaseCard(vendor) {
    const img = image(vendor);
    return `
      <article class="venue-showcase-card" style="--image: ${imageCss(vendor)}">
        <div class="venue-showcase-media" role="img" aria-label="${img.alt}"></div>
        <div class="venue-showcase-body">
          <span class="pill gold">Featured Sydney venue</span>
          <h3>${vendor.name}</h3>
          <p>${vendor.location}</p>
          <div class="quick-row">${vendor.tags.slice(0, 3).map((tag) => `<span class="pill">${tag}</span>`).join("")}<span class="pill">Capacity: enquire</span><span class="pill">${vendor.priceGuide}</span></div>
          <div class="share-row">
            <a class="button secondary compact" href="${vendorUrl(vendor)}" data-vendor-open="${vendor.slug}">View venue</a>
            <button class="text-link" type="button" data-save-type="venues" data-save-item="${vendor.slug}" data-label="Save">Save</button>
          </div>
        </div>
      </article>`;
  }

  function guideCard(item, type) {
    const img = image(item.imageKey);
    return `
      <article class="guide-card" style="--image: url('${img.url}')">
        <div class="guide-card-media" role="img" aria-label="${img.alt}"></div>
        <div class="guide-card-body">
          <span class="pill gold">${type === "guides" ? "Venue guide" : "Planning guide"}</span>
          <h3>${item.title}</h3>
          <p>${item.intro}</p>
          <a class="button secondary compact" href="${itemUrl(type, item)}">Read guide</a>
        </div>
      </article>`;
  }

  function renderCategories() {
    const el = document.querySelector("[data-categories]");
    if (!el) return;
    const editorialCategories = [
      ["Venues", "Harbour rooms, city landmarks and garden estates", "Venues", "venue"],
      ["Photographers", "Editorial, documentary and quietly candid images", "Photographers", "portrait"],
      ["Hair & Makeup", "Calm getting-ready mornings and polished beauty", "Bridal Hair and Makeup", "ceremony"],
      ["Florists", "Seasonal flowers and sculptural ceremony work", "Florists / Stylists", "florals"],
      ["Celebrants", "Personal ceremonies with warmth and clarity", "Celebrants", "harbour"],
      ["Entertainment", "Live music, considered playlists and late nights", "Entertainment / DJs", "music"],
      ["Caterers", "Menus shaped around place, season and celebration", "Caterers", "catering"],
      ["Cakes & beauty", "Finishing details, from cake to getting ready", "Wedding Cakes", "cake"]
    ];
    el.innerHTML = editorialCategories.map(([label, note, category, imageKey]) => `<a class="category-card" data-category-select="${category}" href="${href("/categories/")}?category=${encodeURIComponent(category)}#vendors" style="--image:url('${image(imageKey).url}')">
      <span><strong>${label}</strong><span class="category-note">${note}</span></span>
    </a>`).join("");
  }

  function renderCollection(selector, items, renderer, limit) {
    const el = document.querySelector(selector);
    if (!el) return;
    el.innerHTML = items.slice(0, limit || items.length).map(renderer).join("");
    setupSaveItems(el);
    setupShareButtons(el);
    setupVendorInteractions(el);
  }

  function renderEditorialSections() {
    renderCollection("[data-inspiration-cards]", data.inspirationStyles, inspirationCard);
    renderCollection("[data-home-inspiration]", data.inspirationStyles, inspirationCard, 4);
    renderCollection("[data-real-wedding-cards]", data.realWeddings, realWeddingCard);
    // Future feature: homepage real wedding cards are intentionally hidden for now.
    // renderCollection("[data-home-real-weddings]", data.realWeddings, realWeddingCard, 2);
    renderCollection("[data-featured-venues]", data.vendors.filter((vendor) => vendor.category === "Venues").slice(0, 4), venueShowcaseCard);
    renderCollection("[data-guide-cards]", data.venueGuides, (item) => guideCard(item, "guides"));
    renderCollection("[data-home-guide-cards]", data.venueGuides.slice(0, 3), (item) => guideCard(item, "guides"));
    renderCollection("[data-planning-guide-cards]", data.planningGuides, (item) => guideCard(item, "planning"));
  }

  function renderRealWeddingDetail() {
    const el = document.querySelector("[data-real-wedding-detail]");
    if (!el) return;
    const slug = el.dataset.realWeddingDetail || pathParts[pathParts.length - 2] || pathParts[pathParts.length - 1];
    const item = data.realWeddings.find((wedding) => wedding.slug === slug) || data.realWeddings[0];
    const img = image(item.imageKey);
    addRecentlyViewed({ type: "Example wedding", title: item.title, url: `/real-weddings/${item.slug}/` });
    document.title = `${item.title} | Wed in Sydney`;
    setMeta("description", `${item.label}: ${item.description}`, false);
    setMeta("og:title", item.title, true);
    setMeta("og:description", item.description, true);
    setMeta("og:image", img.url, true);
    el.innerHTML = `
      <section class="profile-hero">
        <div class="shell">
          <nav class="breadcrumb"><a href="${href("/")}">Home</a><span>/</span><span>Real Sydney weddings</span><span>/</span><span>${item.coupleNames}</span></nav>
          <div class="article-hero" style="--image:url('${img.url}')">
            <div><span class="pill gold">${item.label}</span><h1>${item.title}</h1><p class="lede">${item.description}</p></div>
          </div>
          <div class="detail-meta-grid">
            <span><strong>Couple</strong>${item.coupleNames}</span><span><strong>Venue</strong>${item.venue}</span><span><strong>Location</strong>${item.location}</span><span><strong>Guests</strong>${item.guestCount}</span><span><strong>Style</strong>${item.style}</span>
          </div>
        </div>
      </section>
      <section><div class="shell copy-grid"><div><span class="eyebrow">Planning story</span><h2>How this day could come together.</h2><div class="share-row"><button class="button secondary" type="button" data-save-type="realWeddings" data-save-item="${item.slug}" data-label="Save wedding">Save wedding</button><button class="button secondary" type="button" data-copy-link="${location.href}">Share this inspiration</button></div></div><div>${item.storySections.map((section) => `<p>${section}</p>`).join("")}<p><strong>Supplier categories:</strong> ${item.supplierCategories.join(", ")}.</p></div></div></section>
      <section><div class="shell"><div class="section-head"><div><span class="eyebrow">Similar inspiration</span><h2>Browse weddings like yours.</h2></div></div><div class="grid">${data.inspirationStyles.slice(0, 3).map(inspirationCard).join("")}</div></div></section>
      <section><div class="shell panel"><h2>Build your shortlist</h2><p>Save this story, then compare the suppliers and styles that feel closest to your own day.</p><div class="share-row"><a class="button" href="${href("/shortlist/")}">Build your shortlist</a><a class="button secondary" href="${href("/categories/")}">Browse suppliers</a></div></div></section>`;
    setupSaveItems(el);
    setupShareButtons(el);
    renderRecentlyViewed();
    injectArticleSchema(item.title, item.description, img.url);
  }

  function renderInspirationDetail() {
    const el = document.querySelector("[data-inspiration-detail]");
    if (!el) return;
    const slug = el.dataset.inspirationDetail || pathParts[pathParts.length - 2] || pathParts[pathParts.length - 1];
    const item = data.inspirationStyles.find((style) => style.slug === slug) || data.inspirationStyles[0];
    const img = image(item.imageKey);
    addRecentlyViewed({ type: "Inspiration", title: item.title, url: `/inspiration/${item.slug}/` });
    document.title = `${item.title} | Wedding Inspiration | Wed in Sydney`;
    setMeta("description", item.moodDescription, false);
    setMeta("og:title", `${item.title} | Wed in Sydney`, true);
    setMeta("og:description", item.moodDescription, true);
    setMeta("og:image", img.url, true);
    el.innerHTML = `
      <section class="profile-hero">
        <div class="shell">
          <nav class="breadcrumb"><a href="${href("/")}">Home</a><span>/</span><a href="${href("/inspiration/")}">Inspiration</a><span>/</span><span>${item.title}</span></nav>
          <div class="article-hero" style="--image:url('${img.url}')"><div><span class="pill gold">Inspired by Sydney wedding styles</span><h1>${item.title}</h1><p class="lede">${item.moodDescription}</p></div></div>
        </div>
      </section>
      <section><div class="shell guide-grid"><article class="panel"><h3>Suggested venues</h3><p>${item.suggestedVenues.join(", ")}</p></article><article class="panel"><h3>Supplier categories</h3><p>${item.suggestedSupplierCategories.join(", ")}</p></article><article class="panel"><h3>Style notes</h3><p>${item.tags.join(", ")}</p></article></div></section>
      <section><div class="shell panel"><h2>Build your shortlist</h2><p>Keep this mood in your shortlist, or copy the link to send to someone planning with you.</p><div class="share-row"><button class="button" type="button" data-save-type="inspiration" data-save-item="${item.slug}" data-label="Save inspiration">Save inspiration</button><button class="button secondary" type="button" data-copy-link="${location.href}">Share this inspiration</button><a class="button secondary" href="${href("/shortlist/")}">Build your shortlist</a><a class="button secondary" href="${href("/venues/")}">Browse venues</a></div></div></section>`;
    setupSaveItems(el);
    setupShareButtons(el);
    renderRecentlyViewed();
    injectArticleSchema(item.title, item.moodDescription, img.url);
  }

  function renderGuideDetail(kind) {
    const attr = kind === "guides" ? "data-guide-detail" : "data-planning-detail";
    const el = document.querySelector(`[${attr}]`);
    if (!el) return;
    const list = kind === "guides" ? data.venueGuides : data.planningGuides;
    const slug = el.getAttribute(attr) || pathParts[pathParts.length - 2] || pathParts[pathParts.length - 1];
    const item = list.find((guide) => guide.slug === slug) || list[0];
    const img = image(item.imageKey);
    addRecentlyViewed({ type: kind === "guides" ? "Guide" : "Planning guide", title: item.title, url: `/${kind}/${item.slug}/` });
    document.title = `${item.title} | Wed in Sydney`;
    setMeta("description", item.intro, false);
    setMeta("og:title", item.title, true);
    setMeta("og:description", item.intro, true);
    setMeta("og:image", img.url, true);
    const venueRows = (item.venueList || []).map((name) => {
      const vendor = data.vendors.find((v) => v.name === name);
      return `<tr><td>${name}</td><td>${vendor ? vendor.location : "Sydney"}</td><td>${vendor ? vendor.priceGuide : "Request quote"}</td></tr>`;
    }).join("");
    el.innerHTML = `
      <section class="profile-hero"><div class="shell"><nav class="breadcrumb"><a href="${href("/")}">Home</a><span>/</span><a href="${href(kind === "guides" ? "/guides/" : "/planning/")}">${kind === "guides" ? "Venue guides" : "Planning guides"}</a><span>/</span><span>${item.title}</span></nav><div class="article-hero" style="--image:url('${img.url}')"><div><span class="pill gold">${kind === "guides" ? "Venue guide" : "Planning guide"}</span><h1>${item.title}</h1><p class="lede">${item.intro}</p></div></div></div></section>
      <section><div class="shell copy-grid"><div><span class="eyebrow">Guide notes</span><h2>${kind === "guides" ? "Compare with context." : "Make the next decision easier."}</h2><div class="share-row"><button class="button secondary" type="button" data-copy-link="${location.href}">Copy link</button><a class="button" href="${href(kind === "guides" ? "/venues/" : "/categories/")}">${kind === "guides" ? "Browse venues" : "Browse suppliers"}</a></div></div><div>${(item.sections || [item.budgetNotes]).map((section) => `<p>${section}</p>`).join("")}${item.budgetNotes ? `<p><strong>Budget note:</strong> ${item.budgetNotes}</p>` : ""}</div></div></section>
      ${venueRows ? `<section><div class="shell"><div class="table-wrap"><table><thead><tr><th>Venue</th><th>Location</th><th>Pricing note</th></tr></thead><tbody>${venueRows}</tbody></table></div></div></section>` : ""}
      ${item.checklist ? `<section><div class="shell"><div class="section-head"><div><span class="eyebrow">Checklist</span><h2>Keep these close.</h2></div></div><div class="guide-grid">${item.checklist.map((check) => `<article class="panel"><h3>${check}</h3><p>Use this as a prompt when comparing options.</p></article>`).join("")}</div></div></section>` : ""}
      <section><div class="shell faq-grid">${item.faqs.map((faq) => `<article class="faq-item"><h3>${faq[0]}</h3><p>${faq[1]}</p></article>`).join("")}</div></section>
      <section><div class="shell panel"><h2>${kind === "guides" ? "View related suppliers" : "Keep planning"}</h2><p>${kind === "guides" ? "Use this guide as a starting point, then compare supplier profiles and direct websites." : "Open a related page or save useful ideas for later."}</p><div class="share-row"><a class="button" href="${href(kind === "guides" ? "/venues/" : "/categories/")}">${kind === "guides" ? "View related suppliers" : "Browse suppliers"}</a>${item.internalLinks.map((link) => `<a class="button secondary" href="${href(link)}">Explore</a>`).join("")}</div></div></section>
      <section><div class="shell panel"><h2>Recently viewed</h2><div data-recently-viewed></div></div></section>`;
    setupShareButtons(el);
    renderRecentlyViewed();
    injectArticleSchema(item.title, item.intro, img.url);
    injectCustomFaqSchema(item.faqs);
  }

  function setupSearch() {
    const form = document.querySelector("[data-search-form]");
    if (!form) return;
    const input = form.querySelector("[data-search-input]");
    const category = form.querySelector("[data-category-filter]");
    const style = form.querySelector("[data-style-filter]");
    const area = form.querySelector("[data-area-filter]");
    const budgetFeel = form.querySelector("[data-budget-feel-filter]");
    const output = document.querySelector("[data-search-results]");
    const summary = document.querySelector("[data-result-summary]");
    const baseCategory = form.dataset.baseCategory || "all";
    const baseLocation = form.dataset.baseLocation || "";
    const initialLimit = Number(form.dataset.initialLimit || 0);
    const requestedCategory = new URLSearchParams(location.search).get("category");
    if (!form.querySelector("[data-clear-search]")) {
      const clearButton = document.createElement("button");
      clearButton.className = "button secondary compact search-reset";
      clearButton.type = "button";
      clearButton.dataset.clearSearch = "";
      clearButton.textContent = "Clear";
      form.querySelector(".search-row")?.appendChild(clearButton);
    }
    const clearControls = Array.from(form.querySelectorAll("[data-clear-search]"));
    if (category && requestedCategory && Array.from(category.options).some((option) => option.value === requestedCategory)) {
      category.value = requestedCategory;
    }

    function normalizeSearch(text) {
      return String(text || "")
        .toLowerCase()
        .replace(/&/g, " and ")
        .replace(/[^a-z0-9]+/g, " ")
        .replace(/\bphotographers\b/g, "photographer")
        .replace(/\bphotography\b/g, "photographer")
        .replace(/\bphotos\b/g, "photo")
        .replace(/\bvenues\b/g, "venue")
        .replace(/\bflorists\b/g, "florist")
        .replace(/\bflowers\b/g, "florist")
        .replace(/\bcelebrants\b/g, "celebrant")
        .replace(/\bcaterers\b/g, "caterer")
        .replace(/\bcatering\b/g, "caterer")
        .replace(/\bcakes\b/g, "cake")
        .replace(/\bdjs\b/g, "dj")
        .replace(/\bmakeup\b/g, "make up")
        .replace(/\s+/g, " ")
        .trim();
    }

    function matchesText(vendor, q) {
      if (!q) return true;
      const categoryIntent = {
        venue: "Venues",
        photographer: "Photographers",
        celebrant: "Celebrants",
        florist: "Florists / Stylists",
        stylist: "Florists / Stylists",
        dj: "Entertainment / DJs",
        entertainment: "Entertainment / DJs",
        caterer: "Caterers",
        cake: "Wedding Cakes",
        hair: "Bridal Hair and Makeup",
        beauty: "Bridal Hair and Makeup"
      };
      const haystack = normalizeSearch([
        vendor.name,
        vendor.category,
        vendor.location,
        vendor.area,
        vendor.budgetFeel,
        vendor.description,
        vendor.tags.join(" "),
        vendor.services.join(" "),
        vendor.areasServiced.join(" ")
      ].join(" "));
      return normalizeSearch(q).split(" ").every((term) => {
        if (categoryIntent[term]) return vendor.category === categoryIntent[term];
        return haystack.includes(term);
      });
    }

    function matchesLocation(vendor) {
      if (!baseLocation || baseLocation === "sydney") return true;
      if (["parramatta", "northern"].includes(baseLocation) && /sydney-wide|greater sydney|sydney|nsw/i.test(vendor.areasServiced.join(" "))) return true;
      return `${vendor.location} ${vendor.areasServiced.join(" ")}`.toLowerCase().includes(baseLocation);
    }

    function update() {
      const q = input ? input.value.trim() : "";
      const selectedCategory = category ? category.value : baseCategory;
      const selectedStyle = style ? style.value : "all";
      const selectedArea = area ? area.value : "all";
      const selectedBudgetFeel = budgetFeel ? budgetFeel.value : "all";
      const filtered = data.vendors
        .filter((vendor) => selectedCategory === "all" || vendor.category === selectedCategory)
        .filter((vendor) => selectedArea === "all" || vendor.area === selectedArea)
        .filter((vendor) => selectedBudgetFeel === "all" || vendor.budgetFeel === selectedBudgetFeel)
        .filter(matchesLocation)
        .filter((vendor) => selectedStyle === "all" || selectedStyle === "0" || vendor.tags.includes(selectedStyle))
        .filter((vendor) => matchesText(vendor, q))
        .sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
      const isDefault = !q && selectedCategory === "all" && selectedStyle === "all" && selectedArea === "all" && selectedBudgetFeel === "all";
      const featuredSlugs = ["zest-waterfront-venues", "gunners-barracks", "salt-atelier", "celebrant-melissa-soncini", "melissa-d-cruz-floral", "the-white-tree"];
      const visible = initialLimit && isDefault
        ? featuredSlugs.map((slug) => data.vendors.find((vendor) => vendor.slug === slug)).filter(Boolean).slice(0, initialLimit)
        : filtered;
      if (output) {
        output.classList.add("is-updating");
        output.innerHTML = visible.length ? visible.map(vendorCard).join("") : `<div class="empty-state"><span class="eyebrow">No exact matches</span><h3>Try a broader search</h3><p>Clear a filter or search by a nearby suburb, service or wedding style.</p><button class="button secondary compact" type="button" data-clear-search>Clear filters</button></div>`;
        setupSaveButtons(output);
        setupVendorInteractions(output);
        requestAnimationFrame(() => output.classList.remove("is-updating"));
        output.querySelector("[data-clear-search]")?.addEventListener("click", resetSearch);
      }
      if (summary) {
        summary.textContent = isDefault && initialLimit
          ? "A considered selection of Sydney wedding professionals."
          : `${filtered.length} vendor${filtered.length === 1 ? "" : "s"} found.`;
      }
      clearControls.forEach((button) => {
        const hasFilters = Boolean(q) || selectedCategory !== baseCategory || selectedStyle !== "all" || selectedArea !== "all" || selectedBudgetFeel !== "all";
        button.disabled = !hasFilters;
        button.classList.toggle("is-muted", !hasFilters);
      });
    }

    function resetSearch() {
      if (input) input.value = "";
      if (category) category.value = baseCategory;
      if (style) style.value = "all";
      if (area) area.value = "all";
      if (budgetFeel) budgetFeel.value = "all";
      document.querySelectorAll("[data-category-select]").forEach((item) => item.classList.remove("is-active"));
      update();
      input?.focus();
    }

    form.addEventListener("submit", (event) => { event.preventDefault(); update(); });
    [input, category, style, area, budgetFeel].forEach((field) => {
      if (!field) return;
      field.addEventListener("input", update);
      field.addEventListener("change", update);
    });
    clearControls.forEach((button) => button.addEventListener("click", resetSearch));
    document.querySelectorAll("[data-shortcut]").forEach((button) => {
      button.addEventListener("click", () => {
        if (category) category.value = button.dataset.shortcut;
        update();
        document.querySelector("#vendors")?.scrollIntoView({ behavior: "smooth" });
      });
    });
    document.querySelectorAll("[data-category-select]").forEach((card) => {
      card.addEventListener("click", (event) => {
        if (!category) return;
        event.preventDefault();
        category.value = card.dataset.categorySelect;
        document.querySelectorAll("[data-category-select]").forEach((item) => item.classList.toggle("is-active", item === card));
        update();
        document.querySelector("#vendors")?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });
    update();
  }

  function setupTools() {
    const budgetInputs = document.querySelectorAll("[data-budget]");
    const result = document.querySelector("[data-budget-result]");
    const breakdown = document.querySelector("[data-budget-breakdown]");
    function updateBudget() {
      if (!result) return;
      const guests = Number(document.querySelector("[data-budget='guests']")?.value || 90);
      const perHead = Number(document.querySelector("[data-budget='perHead']")?.value || 220);
      const extras = Number(document.querySelector("[data-budget='extras']")?.value || 12000);
      const total = guests * perHead + extras;
      result.textContent = `A gentle starting estimate: $${total.toLocaleString("en-AU")}`;
      if (breakdown) {
        const venue = guests * perHead;
        const allocations = [
          ["Venue / catering", venue],
          ["Photography", Math.round(extras * 0.22)],
          ["Celebrant", Math.round(extras * 0.08)],
          ["Florals / styling", Math.round(extras * 0.18)],
          ["Entertainment", Math.round(extras * 0.14)],
          ["Cake", Math.round(extras * 0.06)],
          ["Hair and makeup", Math.round(extras * 0.12)],
          ["Contingency", Math.round(total * 0.1)]
        ];
        breakdown.innerHTML = allocations.map(([label, value]) => `<li><span>${label}</span><strong>$${value.toLocaleString("en-AU")}</strong></li>`).join("");
      }
    }
    budgetInputs.forEach((field) => field.addEventListener("input", updateBudget));
    updateBudget();

    document.querySelectorAll("[data-check]").forEach((box) => {
      const key = `wis-check-${box.value}`;
      box.checked = localStorage.getItem(key) === "true";
      box.addEventListener("change", () => localStorage.setItem(key, box.checked));
    });
  }

  function renderPlanningTools() {
    if (!document.querySelector("[data-planning-guide-cards]") || document.querySelector("#planning-tools")) return;
    const section = document.createElement("section");
    section.id = "planning-tools";
    section.className = "planning-intro";
    section.innerHTML = `<div class="shell copy-grid"><div><span class="eyebrow">Interactive planning</span><h2>Make the next decision easier</h2></div><div><p>These lightweight tools stay on this device, so you can explore numbers and keep track without creating an account.</p></div></div>
      <div class="shell tools-grid refined-tools">
        <article class="tool-card"><span class="tool-number">01</span><h3>Wedding cost calculator</h3><p>Shape an early estimate around your guest count and priorities.</p><label>Guests<input data-budget="guests" type="number" min="1" value="90"></label><label>Per-head venue estimate<input data-budget="perHead" type="number" min="0" value="220"></label><label>Other vendors<input data-budget="extras" type="number" min="0" value="12000"></label><div class="tool-result" data-budget-result></div><ul class="budget-list" data-budget-breakdown></ul></article>
        <article class="tool-card checklist"><span class="tool-number">02</span><h3>Planning checklist</h3><p>A quiet place to keep the essential bookings moving.</p><label><input data-check value="venue" type="checkbox">Shortlist venues</label><label><input data-check value="photo" type="checkbox">Compare photographers</label><label><input data-check value="celebrant" type="checkbox">Choose your celebrant</label><label><input data-check value="enquiries" type="checkbox">Send first enquiries</label></article>
        <article class="tool-card"><span class="tool-number">03</span><h3>Vendor comparison</h3><p>Add up to three vendors from the directory, then compare the details that matter.</p><div data-compare-suppliers></div><a class="text-link" href="${href("/categories/")}">Browse vendors</a></article>
      </div>`;
    document.querySelector("[data-planning-guide-cards]").closest("section")?.after(section);
  }

  function setupStyleFinder() {
    const form = document.querySelector("[data-style-finder]");
    if (!form) return;
    const output = form.querySelector("[data-style-finder-result]");
    const update = () => {
      const setting = form.querySelector("[name='setting']")?.value || "Harbour";
      const guests = form.querySelector("[name='guests']")?.value || "60-120";
      const budget = form.querySelector("[name='budget']")?.value || "Mid-range";
      const recommendation = data.styleFinder.recommendations[setting] || data.styleFinder.recommendations.Harbour;
      output.innerHTML = `
        <strong>${setting} wedding direction</strong>
        <p>${recommendation[0]} For ${guests.toLowerCase()} guests with a ${budget.toLowerCase()} feel, shortlist a venue first, then compare photography, celebrant and styling options.</p>
        <div class="share-row"><a class="button secondary compact" href="${href(recommendation[1])}">Explore this style</a><a class="button secondary compact" href="${href(recommendation[2])}">View next step</a></div>`;
    };
    form.addEventListener("input", update);
    update();
  }

  function viewedItems() {
    return parseStored("wis-recently-viewed", []);
  }

  function addRecentlyViewed(item) {
    const next = [item, ...viewedItems().filter((entry) => entry.url !== item.url)].slice(0, 6);
    localStorage.setItem("wis-recently-viewed", JSON.stringify(next));
  }

  function renderRecentlyViewed() {
    const targets = document.querySelectorAll("[data-recently-viewed]");
    if (!targets.length) return;
    const items = viewedItems();
    targets.forEach((el) => {
      el.innerHTML = items.length ? `
        <div class="compare-list light">
          ${items.map((item) => `<article><strong>${item.title}</strong><span>${item.type}</span><a class="text-link" href="${href(item.url)}">Open</a></article>`).join("")}
        </div>` : "<p>Recently viewed suppliers, guides and inspiration will appear here.</p>";
    });
  }

  function renderCompareSuppliers() {
    const el = document.querySelector("[data-compare-suppliers]");
    if (!el) return;
    const vendors = compareItems()
      .map((slug) => data.vendors.find((vendor) => vendor.slug === slug))
      .filter(Boolean)
      .slice(0, 3);
    if (!vendors.length) {
      el.innerHTML = `<p>Add up to three suppliers using the Compare button. Your comparison stays on this device.</p><a class="text-link" href="${href("/categories/")}">Browse vendors</a>`;
      return;
    }
    el.innerHTML = `
      <div class="table-wrap compare-table"><table><thead><tr><th>Supplier</th><th>Location</th><th>Style</th><th>Price note</th><th>Services</th><th>Website</th></tr></thead><tbody>
      ${vendors.map((vendor) => `<tr><td>${vendor.name}<br><small>${vendor.category}</small></td><td>${vendor.location}</td><td>${vendor.tags.slice(0, 3).join(", ")}</td><td>${vendor.priceGuide}</td><td>${vendor.services.slice(0, 3).join(", ")}</td><td><button class="text-link" type="button" data-vendor-open="${vendor.slug}">View</button><br><button class="text-link" type="button" data-compare-vendor="${vendor.slug}">Remove</button></td></tr>`).join("")}
      </tbody></table></div>`;
    setupVendorInteractions(el);
  }

  function renderShortlist() {
    const el = document.querySelector("[data-shortlist]");
    if (!el) return;
    const supplierSlugs = readSaved("suppliers");
    const venueSlugs = readSaved("venues");
    const inspirationSlugs = readSaved("inspiration");
    const vendors = supplierSlugs
      .map((slug) => data.vendors.find((vendor) => vendor.slug === slug))
      .filter(Boolean);
    const venues = venueSlugs
      .map((slug) => data.vendors.find((vendor) => vendor.slug === slug))
      .filter(Boolean);
    const inspiration = inspirationSlugs
      .map((slug) => data.inspirationStyles.find((item) => item.slug === slug))
      .filter(Boolean);
    if (![vendors, venues, inspiration].some((items) => items.length)) {
      el.innerHTML = `
        <p>Save suppliers, venues or inspiration styles and they will appear here for an easy side-by-side check.</p>
        <p class="tool-result">Your shortlist is empty for now.</p>`;
      return;
    }

    const supplierGroup = (title, items) => items.length ? `
      <section class="shortlist-group"><h2>${title}</h2><div class="compare-list">
        ${items.map((vendor) => `
          <article>
            <strong>${vendor.name}</strong>
            <span>${vendor.category}</span>
            <span>${vendor.location}</span>
            <a class="text-link" href="${vendorUrl(vendor)}" data-vendor-open="${vendor.slug}">View profile</a>
          </article>
        `).join("")}
      </div></section>` : "";
    const editorialGroup = (title, items, type) => items.length ? `
      <section class="shortlist-group"><h2>${title}</h2><div class="compare-list">
        ${items.map((item) => `
          <article>
            <strong>${item.title || item.coupleNames}</strong>
            <span>${item.style || item.moodDescription}</span>
            <a class="text-link" href="${itemUrl(type, item)}">Open</a>
          </article>
        `).join("")}
      </div></section>` : "";

    el.innerHTML = [
      supplierGroup("Suppliers", vendors),
      supplierGroup("Venues", venues),
      editorialGroup("Inspiration", inspiration, "inspiration")
    ].join("");
    setupVendorInteractions(el);
  }

  function promptsForVendor(vendor) {
    return data.questionPrompts[vendor.category] || data.questionPrompts.default;
  }

  function relatedLinksForVendor(vendor) {
    if (vendor.category === "Venues") return [
      ["/guides/sydney-wedding-venue-cost-guide/", "Venue cost guide"],
      ["/planning/questions-to-ask-wedding-venues/", "Questions to ask venues"],
      ["/inspiration/harbour-weddings/", "Harbour inspiration"]
    ];
    if (vendor.category === "Photographers") return [
      ["/planning/how-much-does-a-wedding-photographer-cost/", "Photography cost guide"],
      ["/inspiration/harbour-weddings/", "Harbour inspiration"],
      ["/celebrants/", "Browse celebrants"]
    ];
    return [
      ["/planning/how-to-compare-wedding-suppliers/", "Compare suppliers"],
      ["/inspiration/", "Browse inspiration"],
      ["/shortlist/", "Open shortlist"]
    ];
  }

  function nextStepForVendor(vendor) {
    if (vendor.category === "Venues") return ["Save venue", "/photographers/", "Browse photographers"];
    if (vendor.category === "Photographers") return ["Save photographer", "/celebrants/", "Browse celebrants"];
    return ["Save supplier", "/shortlist/", "Build your shortlist"];
  }

  function renderProfile() {
    const el = document.querySelector("[data-profile]");
    if (!el) return;
    const lastPathPart = pathParts[pathParts.length - 1];
    const slug = el.dataset.profile || (lastPathPart === "index.html" ? pathParts[pathParts.length - 2] : lastPathPart);
    const vendor = data.vendors.find((item) => item.slug === slug) || data.vendors[0];
    const similar = data.vendors.filter((item) => item.category === vendor.category && item.slug !== vendor.slug).slice(0, 3);
    const mainImage = image(vendor);
    const gallery = [vendor.imageKey, "harbour", "reception"].map((key) => image(key));
    const relatedLinks = relatedLinksForVendor(vendor);
    const nextStep = nextStepForVendor(vendor);
    const saveControl = vendor.category === "Venues"
      ? `data-save-type="venues" data-save-item="${vendor.slug}" data-label="${nextStep[0]}"`
      : `data-save-vendor="${vendor.slug}"`;
    addRecentlyViewed({ type: "Supplier", title: vendor.name, url: `/vendor/${vendor.slug}/` });

    document.title = `${vendor.name} | ${displayCategory(vendor.category)} in ${vendor.location} | Wed in Sydney`;
    const metaDescription = `${vendor.name} is a ${displayCategory(vendor.category).toLowerCase()} supplier serving ${vendor.location}. Compare services, areas serviced and request pricing.`;
    setMeta("description", metaDescription, false);
    setMeta("og:title", `${vendor.name} | Wed in Sydney`, true);
    setMeta("og:description", metaDescription, true);
    setMeta("og:image", mainImage.url, true);
    setMeta("twitter:card", "summary_large_image", false);
    const businessSchema = document.createElement("script");
    businessSchema.type = "application/ld+json";
    businessSchema.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": vendor.name,
      "image": mainImage.url,
      "address": {
        "@type": "PostalAddress",
        "addressLocality": vendor.location,
        "addressRegion": "NSW",
        "addressCountry": "AU"
      }
    });
    const verifiedUrl = verifiedWebsiteUrl(vendor);
    if (verifiedUrl) {
      const schema = JSON.parse(businessSchema.textContent);
      schema.url = verifiedUrl;
      businessSchema.textContent = JSON.stringify(schema);
    }
    document.head.appendChild(businessSchema);

    el.innerHTML = `
      <section class="profile-hero">
        <div class="shell">
          <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="${href("/")}">Home</a><span>/</span><a href="${href("/categories/")}">Categories</a><span>/</span><span>${vendor.name}</span>
          </nav>
          <div class="profile-grid">
            <div>
              <div class="gallery">
                <img src="${gallery[0].url}" alt="${gallery[0].alt}">
                <div>
                  <img src="${gallery[1].url}" alt="${gallery[1].alt}">
                  <img src="${gallery[2].url}" alt="${gallery[2].alt}" style="margin-top:12px">
                </div>
              </div>
              <section>
                <span class="eyebrow">Supplier profile</span>
                <h1>${vendor.name}</h1>
                <p class="lede">${vendor.description} Save this supplier, explore similar options and ask about availability when the fit feels right.</p>
                <div class="quick-row">
                  <span class="pill">${displayCategory(vendor.category)}</span>
                  <span class="pill">${vendor.location}</span>
                  <span class="pill">${vendor.area}</span>
                  <span class="pill">${vendor.budgetFeel}</span>
                  <span class="pill gold">${vendor.priceGuide}</span>
                </div>
              </section>
            </div>
            <aside class="profile-card" id="contact">
              <h3>Enquire with this supplier</h3>
              <p>Ask about availability, packages and pricing. Share your date, guest count and what you love about their style.</p>
              <form class="form-grid" action="mailto:hello@wedinsydney.com" method="post" enctype="text/plain">
                <label>Your name<input name="name" required></label>
                <label>Email<input type="email" name="email" required></label>
                <label>Wedding date<input type="date" name="date"></label>
                <label>Message<textarea name="message" placeholder="Tell them your date, guest count and the kind of celebration you are planning."></textarea></label>
                <button class="button" type="submit">Enquire with this supplier</button>
                <button class="button secondary" type="button" ${saveControl}>${nextStep[0]}</button>
                ${vendorWebsiteCta(vendor, "text-link external-link")}
              </form>
            </aside>
          </div>
        </div>
      </section>
      <section>
        <div class="shell guide-grid">
          <article class="panel"><h3>Services offered</h3><ul class="service-list">${vendor.services.map((item) => `<li>${item}</li>`).join("")}</ul></article>
          <article class="panel"><h3>Areas serviced</h3><p>${vendor.areasServiced.join(", ")}.</p></article>
          <article class="panel"><h3>Notes for couples</h3><p>Public supplier information. Use this as a starting point for your own research. Website links are only shown when verified.</p><p>${vendor.reviewNote}. ${vendor.priceGuide}.</p></article>
        </div>
      </section>
      <section>
        <div class="shell">
          <div class="section-head"><div><span class="eyebrow">Questions to ask</span><h2>Send a more useful enquiry.</h2><p>These prompts help you compare suppliers without needing exact prices upfront.</p></div></div>
          <div class="guide-grid">${promptsForVendor(vendor).map((question) => `<article class="faq-item"><h3>${question}</h3><p>Add this to your enquiry if it matters for your date, guest count or wedding style.</p></article>`).join("")}</div>
        </div>
      </section>
      <section>
        <div class="shell guide-grid">
          <article class="panel"><h3>Helpful links</h3><div class="compare-list light">${relatedLinks.map(([url, label]) => `<article><strong>${label}</strong><a class="text-link" href="${href(url)}">Open</a></article>`).join("")}</div></article>
          <article class="panel"><h3>Recently viewed</h3><div data-recently-viewed></div></article>
          <article class="panel"><h3>Next step</h3><p>Keep this supplier close, then compare the next part of your day.</p><div class="share-row"><button class="button secondary" type="button" ${saveControl}>${nextStep[0]}</button><a class="button" href="${href(nextStep[1])}">${nextStep[2]}</a></div></article>
        </div>
      </section>
      <section>
        <div class="shell">
          <div class="section-head"><div><span class="eyebrow">Similar suppliers</span><h2>Keep shaping your shortlist.</h2></div></div>
          <div class="grid">${similar.map(vendorCard).join("")}</div>
        </div>
      </section>`;
    setupSaveButtons(el);
    setupSaveItems(el);
    renderRecentlyViewed();
  }

  function injectFaqSchema() {
    const faq = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How should we compare Sydney wedding suppliers?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Start with the style of celebration you want, then compare location, services, pricing notes and availability before sending enquiries."
          }
        },
        {
          "@type": "Question",
          "name": "Can we request pricing?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes. Supplier profiles include enquiry prompts so couples can ask about packages, availability and pricing."
          }
        }
      ]
    };
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(faq);
    document.head.appendChild(script);
  }

  function injectBreadcrumbSchema() {
    const crumbs = Array.from(document.querySelectorAll(".breadcrumb a, .breadcrumb span"))
      .map((node) => node.textContent.trim())
      .filter((text) => text && text !== "/");
    if (!crumbs.length) return;
    const schema = {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": crumbs.map((name, index) => ({
        "@type": "ListItem",
        "position": index + 1,
        "name": name
      }))
    };
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(schema);
    document.head.appendChild(script);
  }

  function injectArticleSchema(title, description, imageUrl) {
    const schema = {
      "@context": "https://schema.org",
      "@type": "Article",
      "headline": title,
      "description": description,
      "image": imageUrl,
      "author": {
        "@type": "Organization",
        "name": "Wed in Sydney"
      }
    };
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(schema);
    document.head.appendChild(script);
  }

  function injectCustomFaqSchema(faqs) {
    if (!faqs || !faqs.length) return;
    const schema = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": faqs.map((faq) => ({
        "@type": "Question",
        "name": faq[0],
        "acceptedAnswer": {
          "@type": "Answer",
          "text": faq[1]
        }
      }))
    };
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(schema);
    document.head.appendChild(script);
  }

  function setupPageExperience() {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const revealSelectors = [
      "main > section",
      ".section-head",
      ".category-card",
      ".vendor-card",
      ".editorial-card",
      ".guide-card",
      ".venue-showcase-card",
      ".tool-card",
      ".panel",
      ".faq-item",
      ".trust-item",
      ".timeline article"
    ];

    const setupHeaderState = () => {
      const header = document.querySelector(".site-header");
      if (!header) return;
      const updateHeader = () => header.classList.toggle("is-scrolled", window.scrollY > 8);
      updateHeader();
      window.addEventListener("scroll", updateHeader, { passive: true });
    };

    const setupRevealAnimations = () => {
      const targets = revealSelectors.flatMap((selector) => Array.from(document.querySelectorAll(selector)));
      const uniqueTargets = Array.from(new Set(targets)).filter((target) => !target.dataset.revealReady);
      uniqueTargets.forEach((target) => {
        target.dataset.revealReady = "true";
        target.classList.add("reveal-item");
      });
      document.querySelectorAll(".category-grid, .vendor-grid, .editorial-grid, .tools-grid, .guide-grid, .faq-grid").forEach((group) => {
        Array.from(group.children).forEach((child, index) => {
          child.style.setProperty("--reveal-index", String(Math.min(index, 8)));
        });
      });
      if (reduceMotion) {
        uniqueTargets.forEach((target) => target.classList.add("is-visible"));
        return;
      }
      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        });
      }, { rootMargin: "0px 0px -10% 0px", threshold: 0.08 });
      uniqueTargets.forEach((target) => observer.observe(target));
    };

    requestAnimationFrame(() => document.body.classList.add("is-ready"));
    setupHeaderState();
    setupRevealAnimations();
    document.addEventListener("click", (event) => {
      if (event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button > 0) return;
      const link = event.target.closest("a[href]");
      if (!link || link.target === "_blank" || link.hasAttribute("download")) return;
      const raw = link.getAttribute("href");
      if (!raw || raw.startsWith("mailto:") || raw.startsWith("tel:") || raw.startsWith("#vendor=")) return;
      const url = new URL(link.href, location.href);
      if (url.origin !== location.origin) return;
      if (url.pathname === location.pathname && url.search === location.search && url.hash) {
        const target = document.querySelector(url.hash);
        if (target) {
          event.preventDefault();
          target.scrollIntoView({ behavior: "smooth", block: "start" });
          history.pushState(null, "", url.hash);
        }
        return;
      }
      if (url.href !== location.href && !url.hash.startsWith("#vendor=") && !reduceMotion) {
        event.preventDefault();
        document.body.classList.add("is-leaving");
        window.setTimeout(() => {
          location.href = url.href;
        }, 150);
      }
    });
    const syncVendorHash = () => {
      if (location.hash.startsWith("#vendor=")) {
        openVendorModal(decodeURIComponent(location.hash.split("=").slice(1).join("=")));
      } else {
        const dialog = document.querySelector("[data-vendor-modal]");
        if (dialog?.open) {
          dialog.close();
          document.body.classList.remove("modal-open");
        }
      }
    };
    window.addEventListener("hashchange", syncVendorHash);
    window.addEventListener("popstate", syncVendorHash);
    syncVendorHash();
  }

  renderMainNav();
  renderCategories();
  setupSearch();
  renderPlanningTools();
  setupTools();
  setupStyleFinder();
  renderEditorialSections();
  renderRealWeddingDetail();
  renderInspirationDetail();
  renderGuideDetail("guides");
  renderGuideDetail("planning");
  renderProfile();
  setupSaveButtons(document);
  setupSaveItems(document);
  setupShareButtons(document);
  setupVendorInteractions(document);
  renderShortlist();
  renderCompareSuppliers();
  renderCompareTray();
  renderRecentlyViewed();
  injectFaqSchema();
  injectBreadcrumbSchema();
  enhanceFooterLinks();
  setupPageExperience();
})();
